# প্রিন্ট পয়েন্ট ডিজিটাল সার্ভিস পোর্টাল (Print Point Digital Service Portal)

মরিচা বাজার, উখিয়া, কক্সবাজার-এর আধুনিক ডিজিটাল প্রিন্টিং, চাকরির আবেদন, ছবি প্রিন্ট ও অনলাইন সেবা পোর্টাল।

---

## 🚀 Vercel-এ আজীবনের জন্য ফ্রিতে পাবলিশ করার নিয়ম

1. **GitHub Repository তৈরি করুন:**
   - [github.com](https://github.com)-এ লগইন করুন।
   - **New Repository** খুলে নাম দিন (যেমন: `print-point-portal`)।
   - এই ফোল্ডারের ফাইলগুলো সেখানে আপলোড করুন।

2. **Vercel-এ ডিপ্লয় করুন:**
   - [vercel.com](https://vercel.com)-এ যান এবং GitHub দিয়ে লগইন করুন।
   - **"Add New Project"** ক্লিক করে GitHub থেকে আপনার `print-point-portal` সিলেক্ট করুন।
   - Framework Preset স্বয়ংক্রিয়ভাবে **Vite** থাকবে।
   - **"Deploy"** বাটনে ক্লিক করুন।
   - ৬০ সেকেন্ডের মধ্যে আপনার লাইভ লিংক রেডি হয়ে যাবে (যেমন: `https://printpoint.vercel.app`)!

---

## ⚡ Netlify Drop-এ ৩০ সেকেন্ডে পাবলিশ (কোডিং ছাড়া)
- `print-point-dist-production.zip` আনজিপ করে ভেতরের ফাইলগুলো সরাসরি [app.netlify.com/drop](https://app.netlify.com/drop)-এ টেনে ছেড়ে দিলেই সাথে সাথে ওয়েবসাইট লাইভ হয়ে যাবে।

---

## 💻 লোকাল কম্পিউটারে রান করার নিয়ম
```bash
npm install
npm run dev
```
এরপর ব্রাউজারে `http://localhost:3000` ওপেন করুন।
