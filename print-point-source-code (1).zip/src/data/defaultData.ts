import { ServiceItem, PriceTableItem, ShopConfig, Order, Coupon } from '../types';

export const DEFAULT_SHOP_CONFIG: ShopConfig = {
  shopName: 'প্রিন্ট পয়েন্ট (PRINT POINT)',
  tagline: 'Your Digital Service Partner',
  ownerName: 'মুন্না চৌধুরী (Munna Chowdhury)',
  ownerPhoto: '/assets/aistudio/WhatsApp_Image_2026-11-02_at_2.51.14_PM_de0e69d2.jpeg',
  phone: '01887922095',
  whatsapp: '8801887922095',
  email: 'printpoint@gmail.com',
  address: 'মরিচা বাজার (প্রধান সড়ক সংলগ্ন), উখিয়া',
  marketArea: 'মরিচা বাজার, উখিয়া',
  district: 'কক্সবাজার',
  openingHours: 'সকাল ৮:০০ টা - রাত ১০:০০ টা',
  weeklyDays: 'শনিবার - শুক্রবার',
  weeklyOff: 'সপ্তাহের ৭ দিনই খোলা (শুক্রবার জুমার বিরতি)',
  bkashNumber: '01887922095 (Personal)',
  nagadNumber: '01887922095 (Personal)',
  adminPassword: 'admin123',
  noticeBanner: '🎉 বিশেষ অফার! সকল সেবায় আকর্ষণীয় ২০% ডিসকাউন্ট চলছে! ঘরে বসেই অর্ডার করুন ও ফাইল পাঠান।',
  heroBadge: 'উখিয়ার ১ নম্বর ডিজিটাল প্রিন্ট ও কম্পিউটার ল্যাব',
  heroTitle: 'আপনার সকল ডিজিটাল সেবা এখন অনলাইনে!',
  heroHighlight: 'ঘরে বসেই অর্ডার করুন, ফাইল পাঠান, পেমেন্ট করুন, কাজ বুঝে নিন।',
  heroSubtitle: 'চাকরির আবেদন, পাসপোর্ট সাইজ ছবি, কালার প্রিন্ট, ফটোকপি, টাইপিং ও জরুরি সরকারি অনলাইন সেবার জন্য দোকানে এসে ঘণ্টার পর ঘণ্টা বসে থাকার দিন শেষ!',
  websiteUrl: 'https://ais-dev-el6be644rmjnza7zg43qzi-995710624182.asia-east1.run.app',
  globalDiscountPercent: 20,
  globalDiscountText: 'সকল সেবায় থাকছে আকর্ষণীয় ২০% ডিসকাউন্ট %',
  globalDiscountActive: true
};

export const DEFAULT_SERVICES: ServiceItem[] = [
  {
    id: 'photo-edit',
    title: 'পাসপোর্ট সাইজ ছবি তৈরি ও এডিটিং',
    category: 'ছবি ও ল্যাব',
    startingPrice: 30,
    unit: '৪ কপি',
    icon: 'IdCard',
    bgColor: 'bg-blue-50 text-blue-600 border-blue-200',
    textColor: 'text-blue-600',
    description: 'পাসপোর্ট, স্ট্যাম্প, ৪R সাইজ ছবি ল্যাব কোয়ালিটি ওয়াটারপ্রুফ পেপারে তাৎক্ষণিক প্রিন্ট। ব্যাকগ্রাউন্ড পরিবর্তন ও ফেস ক্লিন সুবিধা।',
    estimatedTime: '১০ মিনিট',
    popular: true
  },
  {
    id: 'photo-retouch',
    title: 'ছবি পরিষ্কার ও রিটাচিং',
    category: 'ছবি ও ল্যাব',
    startingPrice: 40,
    unit: 'প্রতি ছবি',
    icon: 'Sparkles',
    bgColor: 'bg-emerald-50 text-emerald-600 border-emerald-200',
    textColor: 'text-emerald-600',
    description: 'পুরনো দাগযুক্ত বা ঘোলা ছবি একদম পরিষ্কার, এইচডি কালারাইজ ও নতুন রূপদান।',
    estimatedTime: '১৫ মিনিট'
  },
  {
    id: 'job-apply',
    title: 'অনলাইন চাকরির আবেদন',
    category: 'অনলাইন সেবা',
    startingPrice: 50,
    unit: 'প্রতি আবেদন',
    icon: 'Briefcase',
    bgColor: 'bg-amber-50 text-amber-600 border-amber-200',
    textColor: 'text-amber-600',
    description: 'সরকারি-বেসরকারি চাকরি, এনজিও, পুলিশ, বিজিবি ও শিক্ষক নিবন্ধনের নির্ভুল আবেদন ফরম পূরণ ও এডমিট কার্ড ডাউনলোড।',
    estimatedTime: '১৫-২০ মিনিট',
    popular: true
  },
  {
    id: 'gov-apply',
    title: 'সরকারি অনলাইন আবেদন',
    category: 'সরকারি সেবা',
    startingPrice: 50,
    unit: 'প্রতি কাজ',
    icon: 'Landmark',
    bgColor: 'bg-indigo-50 text-indigo-600 border-indigo-200',
    textColor: 'text-indigo-600',
    description: 'ই-পাসপোর্ট, পুলিশ ক্লিয়ারেন্স, ড্রাইভিং লাইসেন্স ও সরকারি সকল ভাতা/প্রণোদনা আবেদন।',
    estimatedTime: '২০ মিনিট'
  },
  {
    id: 'nid-birth',
    title: 'জন্মনিবন্ধন ও NID সংক্রান্ত অনলাইন সেবা',
    category: 'সরকারি সেবা',
    startingPrice: 30,
    unit: 'প্রতি সেবা',
    icon: 'FileCheck',
    bgColor: 'bg-cyan-50 text-cyan-600 border-cyan-200',
    textColor: 'text-cyan-600',
    description: 'জন্মনিবন্ধন আবেদন, সংশোধনের তথ্য যাচাই, স্মার্ট NID কার্ড প্রিন্ট ও ভোটার তথ্য সংশোধন অনলাইন ফরম পূরণ।',
    estimatedTime: '১৫ মিনিট',
    popular: true
  },
  {
    id: 'graphics-logo',
    title: 'গ্রাফিক ডিজাইন ও লোগো তৈরি',
    category: 'ডিজাইন',
    startingPrice: 200,
    unit: 'থেকে শুরু',
    icon: 'Palette',
    bgColor: 'bg-purple-50 text-purple-600 border-purple-200',
    textColor: 'text-purple-600',
    description: 'দোকান ও ব্র্যান্ডের আকর্ষণীয় প্রফেশনাল লোগো, ভিজিটিং কার্ড, প্যাড ও সোশ্যাল মিডিয়া ব্যানার ডিজাইন।',
    estimatedTime: '১-২ ঘণ্টা'
  },
  {
    id: 'banner-poster',
    title: 'ব্যানার ও পোস্টার ডিজাইন',
    category: 'ডিজাইন',
    startingPrice: 150,
    unit: 'থেকে শুরু',
    icon: 'Image',
    bgColor: 'bg-rose-50 text-rose-600 border-rose-200',
    textColor: 'text-rose-600',
    description: 'ফ্লেক্স ব্যানার, পিভিসি সাইনবোর্ড, নির্বাচনী পোস্টার, মাহফিলের পোস্টার ও হ্যান্ডবিল ডিজাইন।',
    estimatedTime: '১ ঘণ্টা'
  },
  {
    id: 'typing',
    title: 'বাংলা ও ইংরেজি টাইপিং',
    category: 'টাইপিং & ড্রাফটিং',
    startingPrice: 15,
    unit: 'প্রতি পৃষ্ঠা',
    icon: 'Keyboard',
    bgColor: 'bg-violet-50 text-violet-600 border-violet-200',
    textColor: 'text-violet-600',
    description: 'ইউনিকোড ও বিজয়ে দ্রুত নির্ভুল বাংলা এবং ইংরেজি টাইপিং। এফিডেভিট, দরখাস্ত, প্রশ্নপত্র ও নোটিশ প্রস্তুত।',
    estimatedTime: '১৫ মিনিট'
  },
  {
    id: 'print-copy-scan',
    title: 'প্রিন্ট, ফটোকপি ও স্ক্যান',
    category: 'প্রিন্ট ও কপি',
    startingPrice: 2,
    unit: 'প্রতি পাতা',
    icon: 'Printer',
    bgColor: 'bg-blue-50 text-blue-700 border-blue-200',
    textColor: 'text-blue-700',
    description: 'হাই-স্পিড সাদাকালো ফটোকপি, উভয় পিঠ প্রিন্ট, প্রফেশনাল এইচডি কালার প্রিন্ট ও ৬০০ dpi রঙিন স্ক্যান।',
    estimatedTime: 'তাৎক্ষণিক',
    popular: true
  },
  {
    id: 'pdf-edit-convert',
    title: 'PDF এডিটিং ও কনভার্ট',
    category: 'ডিজিটাল সার্ভিস',
    startingPrice: 20,
    unit: 'প্রতি ফাইল',
    icon: 'FileSpreadsheet',
    bgColor: 'bg-red-50 text-red-600 border-red-200',
    textColor: 'text-red-600',
    description: 'PDF থেকে Word/Excel ফাইল রূপান্তর, পৃষ্ঠা আলাদা করা, একাধিক ফাইল একত্র করা (Merge) ও সাইজ কমানো।',
    estimatedTime: '৫-১০ মিনিট'
  },
  {
    id: 'data-entry',
    title: 'ডাটা এন্ট্রি ও স্প্রেডশিট',
    category: 'ডিজিটাল সার্ভিস',
    startingPrice: 50,
    unit: 'প্রতি শিট',
    icon: 'Database',
    bgColor: 'bg-teal-50 text-teal-700 border-teal-200',
    textColor: 'text-teal-700',
    description: 'এক্সেল শিট তৈরি, ইনভেন্টরি তালিকা, হিসাব সংরক্ষণ ও অফিশিয়াল তথ্য ডাটাবেজ কম্পোজ।',
    estimatedTime: '৩০ মিনিট'
  },
  {
    id: 'custom-it',
    title: 'অন্যান্য কাস্টম কম্পিউটার সেবা',
    category: 'আইটি সেবা',
    startingPrice: 100,
    unit: 'আলোচনা সাপেক্ষে',
    icon: 'Monitor',
    bgColor: 'bg-sky-50 text-sky-600 border-sky-200',
    textColor: 'text-sky-600',
    description: 'উইন্ডোজ সেটআপ, সফটওয়্যার ইনস্টল, ড্রাইভ ফরম্যাটিং, প্রিন্টার কানেকশন ও কম্পিউটার সার্ভিসিং।',
    estimatedTime: '১ ঘণ্টা'
  },
  {
    id: 'cv-resume',
    title: 'CV ও Resume তৈরি',
    category: 'টাইপিং & ড্রাফটিং',
    startingPrice: 100,
    unit: 'থেকে শুরু',
    icon: 'FileText',
    bgColor: 'bg-amber-50 text-amber-700 border-amber-200',
    textColor: 'text-amber-700',
    description: 'আন্তর্জাতিক মানের আধুনিক ফরম্যাটে সিভি (CV), বায়োডাটা ও কভার লেটার তৈরি ও পিডিএফ ফাইল প্রদান।',
    estimatedTime: '২০-৩০ মিনিট',
    popular: true
  },
  {
    id: 'website-builder',
    title: 'ওয়েবসাইট বানানো ও ব্যবসার ওয়েবসাইট',
    category: 'আইটি সেবা',
    startingPrice: 1500,
    unit: 'আলোচনা সাপেক্ষে',
    icon: 'Globe',
    bgColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    textColor: 'text-emerald-700',
    description: 'দোকান, মাদ্রাসা, স্কুলের জন্য আধুনিক ওয়েবসাইট, ফেসবুক পেজ সেটআপ, গুগল ম্যাপ লোকেশন রেজিস্ট্রেশন।',
    estimatedTime: '১-৩ দিন'
  }
];

export const DEFAULT_PRICE_ITEMS: PriceTableItem[] = [
  { id: '1', name: 'সাদাকালো ফটোকপি (A4 এক পিঠ)', category: 'ফটোকপি', price: '৳ ২ / পাতা', serviceKey: 'print-copy-scan', note: '১০০ কপির বেশি হলে বিশেষ ছাড়' },
  { id: '2', name: 'সাদাকালো ফটোকপি (A4 উভয় পিঠ)', category: 'ফটোকপি', price: '৳ ৩.৫০ / পাতা', serviceKey: 'print-copy-scan', note: 'উভয় পিঠ ফটোকপি' },
  { id: '3', name: 'সাদাকালো ফটোকপি (Legal সাইজ)', category: 'ফটোকপি', price: '৳ ৩ / পাতা', serviceKey: 'print-copy-scan', note: 'দলিল ও স্ট্যাম্প কপি' },
  { id: '4', name: 'কালার প্রিন্ট (A4 সাধারণ পেপার)', category: 'কালার প্রিন্ট', price: '৳ ১০ / পাতা', serviceKey: 'print-copy-scan', note: 'অফিস প্রজেক্ট ও অ্যাসাইনমেন্ট' },
  { id: '5', name: 'কালার প্রিন্ট (A4 ১০০+ gsm গ্লসি পেপার)', category: 'কালার প্রিন্ট', price: '৳ ১৫ - ৳ ২০ / পাতা', serviceKey: 'print-copy-scan', note: 'উজ্জ্বল রঙ ও পরিষ্কার প্রিন্ট' },
  { id: '6', name: 'পাসপোর্ট সাইজ ছবি (৪ কপি ল্যাব প্রিন্ট)', category: 'ছবি ল্যাব', price: '৳ ৩০', serviceKey: 'photo-edit', note: 'প্রিমিয়াম ওয়াটারপ্রুফ কোডাক পেপার' },
  { id: '7', name: 'পাসপোর্ট সাইজ ছবি (৮ কপি ল্যাব প্রিন্ট)', category: 'ছবি ল্যাব', price: '৳ ৫০', serviceKey: 'photo-edit', note: 'অতিরিক্ত স্ট্যাম্প সাইজ ফ্রি' },
  { id: '8', name: 'অনলাইন চাকরির আবেদন (সার্কুলার প্রতি)', category: 'অনলাইন সেবা', price: '৳ ৫০ - ৳ ১০০', serviceKey: 'job-apply', note: 'ছবি ও স্বাক্ষর সাইজিং সহ' },
  { id: '9', name: 'প্রফেশনাল জীবনবৃত্তান্ত (CV মেকিং)', category: 'টাইপিং & ডিজাইন', price: '৳ ১০০ - ৳ ২৫০', serviceKey: 'cv-resume', note: 'পিডিএফ ও প্রিন্ট কপি দেওয়া হয়' },
  { id: '10', name: 'বাংলা / ইংরেজি টাইপিং (প্রতি পৃষ্ঠা)', category: 'টাইপিং', price: '৳ ১৫ - ৳ ২৫', serviceKey: 'typing', note: 'এফিডেভিট ও দরখাস্ত' },
  { id: '11', name: 'লেমিনেশন (NID কার্ড / ছোট সাইজ)', category: 'বাইন্ডিং', price: '৳ ২০', serviceKey: 'custom-it', note: 'ওয়াটারপ্রুফ সিল' },
  { id: '12', name: 'লেমিনেশন (A4 সার্টিফিকেট / দলিল)', category: 'বাইন্ডিং', price: '৳ ৩০ - ৳ ৪০', serviceKey: 'custom-it', note: 'ভারী ১০০ মাইক্রন শিট' },
  { id: '13', name: 'স্পাইরাল বুক বাইন্ডিং (১০০ পৃষ্ঠা পর্যন্ত)', category: 'বাইন্ডিং', price: '৳ ৪০ - ৳ ৬০', serviceKey: 'custom-it', note: 'ট্রান্সপারেন্ট কভার সহ' },
  { id: '14', name: 'ডকুমেন্ট স্ক্যান (প্রতি পৃষ্ঠা)', category: 'ডিজিটাল সেবা', price: '৳ ১০', serviceKey: 'print-copy-scan', note: 'উচ্চমানের রঙিন স্ক্যান' },
  { id: '15', name: 'জন্মনিবন্ধন অনলাইন তথ্য যাচাই ও ডাউনলোড', category: 'সরকারি সেবা', price: '৳ ৩০ - ৳ ৫০', serviceKey: 'nid-birth', note: 'কিউআর কোড ভেরিফিকেশন' }
];

export const DEFAULT_COUPONS: Coupon[] = [
  {
    code: 'PRINT20',
    discountPercent: 20,
    maxDiscount: 100,
    minOrder: 150,
    description: '১৫০ টাকার বেশি অর্ডারে ২০% ছাড় (সর্বোচ্চ ১০০ টাকা)',
    active: true
  },
  {
    code: 'EID2026',
    discountPercent: 25,
    maxDiscount: 150,
    minOrder: 200,
    description: 'স্পেশাল উৎসবে ২৫% মেগা ডিসকাউন্ট',
    active: true
  },
  {
    code: 'STUDENT10',
    discountPercent: 10,
    maxDiscount: 50,
    minOrder: 50,
    description: 'ছাত্র-ছাত্রীদের জন্য যেকোনো প্রিন্ট ও টাইপিংয়ে ১০% ছাড়',
    active: true
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'PP-1001',
    service: 'পাসপোর্ট সাইজ ছবি তৈরি ও এডিটিং',
    category: 'ছবি ও ল্যাব',
    name: 'কামাল হোসেন',
    phone: '01812345678',
    qty: '৮ কপি পাসপোর্ট ছবি',
    notes: 'সাদা ব্যাকগ্রাউন্ড করে দিতে হবে, জরুরি প্রয়োজন',
    payment: 'দোকানে এসে ক্যাশ (Cash on Delivery)',
    paymentStatus: 'বকেয়া',
    status: 'সম্পন্ন',
    date: '০২ নভেম্বর ২০২৬',
    time: 'সকাল ১০:১৫',
    estimatedPrice: 50,
    deliveryType: 'দোকান থেকে সংগ্রহ',
    urgent: false
  },
  {
    id: 'PP-1002',
    service: 'অনলাইন চাকরির আবেদন',
    category: 'অনলাইন সেবা',
    name: 'শাহীন আলম',
    phone: '01798765432',
    qty: '১ টি আবেদন',
    notes: 'বাংলাদেশ রেলওয়ে খালাসী পদের সার্কুলারে আবেদন',
    payment: 'বিকাশ (Bkash)',
    paymentStatus: 'পরিশোধিত',
    status: 'কাজ চলছে',
    date: '০২ নভেম্বর ২০২৬',
    time: 'দুপুর ১২:৩০',
    estimatedPrice: 70,
    deliveryType: 'অনলাইন ফাইল ডেলিভারি',
    urgent: true
  },
  {
    id: 'PP-1003',
    service: 'প্রিন্ট, ফটোকপি ও স্ক্যান',
    category: 'প্রিন্ট ও কপি',
    name: 'আব্দুর রহিম',
    phone: '01855667788',
    qty: '৫০ পৃষ্ঠা কালার প্রিন্ট',
    notes: 'উখিয়া কলেজের ফাইনাল প্রজেক্ট পেপার, সুন্দর গ্লসি পেপার চাই',
    payment: 'নগদ (Nagad)',
    paymentStatus: 'পরিশোধিত',
    status: 'প্রস্তুত',
    date: '০২ নভেম্বর ২০২৬',
    time: 'বেলা ০৩:০০',
    estimatedPrice: 400,
    deliveryType: 'দোকান থেকে সংগ্রহ',
    urgent: false
  }
];
