export type OrderStatus = 'গৃহীত' | 'কাজ চলছে' | 'প্রস্তুত' | 'সম্পন্ন' | 'বাতিল';

export interface Order {
  id: string;
  service: string;
  category: string;
  name: string;
  phone: string;
  qty: string;
  notes: string;
  payment: string;
  paymentStatus: 'বকেয়া' | 'পরিশোধিত' | 'আংশিক পরিশোধ';
  status: OrderStatus;
  date: string;
  time: string;
  estimatedPrice: number;
  deliveryType: 'দোকান থেকে সংগ্রহ' | 'অনলাইন ফাইল ডেলিভারি' | 'জরুরি হোম ডেলিভারি';
  urgent: boolean;
  fileName?: string;
  appliedCoupon?: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  category: string;
  startingPrice: number;
  unit: string;
  icon: string;
  imageUrl?: string;
  bgColor: string;
  textColor: string;
  description: string;
  estimatedTime: string;
  popular?: boolean;
}

export interface PriceTableItem {
  id: string;
  name: string;
  category: string;
  price: string;
  serviceKey: string;
  note?: string;
}

export interface ShopConfig {
  shopName: string;
  tagline: string;
  ownerName: string;
  ownerPhoto: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  marketArea: string;
  district: string;
  openingHours: string;
  weeklyDays: string;
  weeklyOff: string;
  bkashNumber: string;
  nagadNumber: string;
  adminPassword: string;
  noticeBanner: string;
  heroBadge: string;
  heroTitle: string;
  heroHighlight: string;
  heroSubtitle: string;
  websiteUrl: string;
  globalDiscountPercent: number;
  globalDiscountText: string;
  globalDiscountActive: boolean;
}

export interface Coupon {
  code: string;
  discountPercent: number;
  maxDiscount: number;
  minOrder: number;
  description: string;
  active: boolean;
}
