import React, { useState } from 'react';
import { 
  X, 
  Lock, 
  Unlock, 
  CheckCircle, 
  Clock, 
  Package, 
  Printer, 
  Phone, 
  MessageCircle, 
  Trash2, 
  Download, 
  Settings, 
  Search, 
  Plus, 
  Edit3, 
  Save, 
  DollarSign, 
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  ExternalLink,
  Store,
  QrCode,
  Tag,
  FileText,
  Sparkles,
  LayoutTemplate,
  Upload
} from 'lucide-react';
import { Order, OrderStatus, ShopConfig, ServiceItem, PriceTableItem, Coupon } from '../types';

interface OwnerAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, status: OrderStatus) => void;
  onUpdatePaymentStatus: (orderId: string, paymentStatus: Order['paymentStatus']) => void;
  onDeleteOrder: (orderId: string) => void;
  shopConfig: ShopConfig;
  onUpdateShopConfig: (newConfig: ShopConfig) => void;
  services: ServiceItem[];
  onUpdateServices: (services: ServiceItem[]) => void;
  priceItems: PriceTableItem[];
  onUpdatePriceItems: (items: PriceTableItem[]) => void;
  coupons: Coupon[];
  onUpdateCoupons: (coupons: Coupon[]) => void;
  onPrintOrder: (order: Order) => void;
  isOwnerMode: boolean;
  setIsOwnerMode: (active: boolean) => void;
  initialTab?: string;
}

export const OwnerAdminModal: React.FC<OwnerAdminModalProps> = ({
  isOpen,
  onClose,
  orders,
  onUpdateOrderStatus,
  onUpdatePaymentStatus,
  onDeleteOrder,
  shopConfig,
  onUpdateShopConfig,
  services,
  onUpdateServices,
  priceItems,
  onUpdatePriceItems,
  coupons,
  onUpdateCoupons,
  onPrintOrder,
  isOwnerMode,
  setIsOwnerMode,
  initialTab = 'orders'
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(isOwnerMode);
  const [passwordInput, setPasswordInput] = useState<string>('');
  const [loginError, setLoginError] = useState<string>('');
  const [activeTab, setActiveTab] = useState<string>(initialTab);

  // Search & Status filters for orders
  const [orderSearch, setOrderSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('সব');

  // Config editor state
  const [configForm, setConfigForm] = useState<ShopConfig>(shopConfig);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  // Services state
  const [editingServices, setEditingServices] = useState<ServiceItem[]>(services);

  // Price Items state
  const [editingPriceItems, setEditingPriceItems] = useState<PriceTableItem[]>(priceItems);

  // Coupons state
  const [editingCoupons, setEditingCoupons] = useState<Coupon[]>(coupons);

  // New service form modal/state
  const [showAddService, setShowAddService] = useState(false);
  const [newServiceTitle, setNewServiceTitle] = useState('');
  const [newServiceCategory, setNewServiceCategory] = useState('অনলাইন সেবা');
  const [newServicePrice, setNewServicePrice] = useState('50');
  const [newServiceUnit, setNewServiceUnit] = useState('থেকে শুরু');
  const [newServiceTime, setNewServiceTime] = useState('১৫ মিনিট');
  const [newServiceDesc, setNewServiceDesc] = useState('');

  // New Price item form
  const [showAddPriceItem, setShowAddPriceItem] = useState(false);
  const [newPriceName, setNewPriceName] = useState('');
  const [newPriceCat, setNewPriceCat] = useState('ফটোকপি');
  const [newPriceRate, setNewPriceRate] = useState('৳ ৫');
  const [newPriceNote, setNewPriceNote] = useState('');

  // New Coupon form
  const [showAddCoupon, setShowAddCoupon] = useState(false);
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponPercent, setNewCouponPercent] = useState('15');
  const [newCouponMax, setNewCouponMax] = useState('100');
  const [newCouponDesc, setNewCouponDesc] = useState('');

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === shopConfig.adminPassword || passwordInput === 'admin123') {
      setIsAuthenticated(true);
      setIsOwnerMode(true);
      setLoginError('');
      setConfigForm(shopConfig);
      setEditingServices(services);
      setEditingPriceItems(priceItems);
      setEditingCoupons(coupons);
    } else {
      setLoginError('ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিন (ডিফল্ট: admin123)');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setIsOwnerMode(false);
    setPasswordInput('');
  };

  const triggerSaveNotice = (msg: string) => {
    setSavedNotice(msg);
    setTimeout(() => setSavedNotice(null), 3000);
  };

  // Metrics
  const totalOrders = orders.length;
  const pendingOrders = orders.filter(o => o.status === 'গৃহীত').length;
  const processingOrders = orders.filter(o => o.status === 'কাজ চলছে').length;
  const completedOrders = orders.filter(o => o.status === 'সম্পন্ন').length;
  const totalRevenue = orders.reduce((sum, o) => sum + (o.estimatedPrice || 0), 0);

  // Filtered orders
  const filteredOrders = orders.filter((o) => {
    const matchesStatus = statusFilter === 'সব' || o.status === statusFilter;
    const query = orderSearch.toLowerCase().trim();
    const matchesSearch =
      !query ||
      o.id.toLowerCase().includes(query) ||
      o.name.toLowerCase().includes(query) ||
      o.phone.includes(query) ||
      o.service.toLowerCase().includes(query);
    return matchesStatus && matchesSearch;
  });

  // Save Settings
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateShopConfig(configForm);
    triggerSaveNotice('দোকান সেটিংস ও সাইটের লেখা সফলভাবে সেভ হয়েছে!');
  };

  // Add Service
  const handleAddNewService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newServiceTitle.trim()) return;

    const newSrv: ServiceItem = {
      id: 'srv-' + Date.now(),
      title: newServiceTitle.trim(),
      category: newServiceCategory,
      startingPrice: parseInt(newServicePrice) || 20,
      unit: newServiceUnit,
      icon: 'Briefcase',
      bgColor: 'bg-blue-50 text-blue-600 border-blue-200',
      textColor: 'text-blue-600',
      description: newServiceDesc.trim() || 'প্রিন্ট পয়েন্ট ডিজিটাল সেবা',
      estimatedTime: newServiceTime,
      popular: false
    };

    const updated = [newSrv, ...editingServices];
    setEditingServices(updated);
    onUpdateServices(updated);

    setNewServiceTitle('');
    setNewServiceDesc('');
    setShowAddService(false);
    triggerSaveNotice(`নতুন সেবা "${newSrv.title}" যোগ করা হয়েছে!`);
  };

  // Delete Service
  const handleDeleteService = (id: string, title: string) => {
    if (window.confirm(`আপনি কি "${title}" সেবাটি মুছে ফেলতে চান?`)) {
      const updated = editingServices.filter(s => s.id !== id);
      setEditingServices(updated);
      onUpdateServices(updated);
      triggerSaveNotice(`"${title}" সেবাটি মুছে ফেলা হয়েছে!`);
    }
  };

  // Update Service Price inline
  const handleServiceChange = (index: number, field: keyof ServiceItem, value: any) => {
    const updated = [...editingServices];
    updated[index] = { ...updated[index], [field]: value };
    setEditingServices(updated);
  };

  const handleSaveServices = () => {
    onUpdateServices(editingServices);
    triggerSaveNotice('সেবাসমূহ সফলভাবে আপডেট করা হয়েছে!');
  };

  // Price Items Manager
  const handleAddPriceItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPriceName.trim()) return;

    const newItem: PriceTableItem = {
      id: 'p-' + Date.now(),
      name: newPriceName.trim(),
      category: newPriceCat,
      price: newPriceRate,
      serviceKey: 'custom',
      note: newPriceNote.trim() || undefined
    };

    const updated = [...editingPriceItems, newItem];
    setEditingPriceItems(updated);
    onUpdatePriceItems(updated);

    setNewPriceName('');
    setNewPriceNote('');
    setShowAddPriceItem(false);
    triggerSaveNotice('মূল্য তালিকায় নতুন আইটেম যুক্ত হয়েছে!');
  };

  const handleDeletePriceItem = (id: string) => {
    const updated = editingPriceItems.filter(p => p.id !== id);
    setEditingPriceItems(updated);
    onUpdatePriceItems(updated);
    triggerSaveNotice('মূল্য তালিকা থেকে আইটেম মোছা হয়েছে!');
  };

  // Coupons Manager
  const handleAddCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;

    const newC: Coupon = {
      code: newCouponCode.trim().toUpperCase(),
      discountPercent: parseInt(newCouponPercent) || 10,
      maxDiscount: parseInt(newCouponMax) || 100,
      minOrder: 100,
      description: newCouponDesc.trim() || `${newCouponPercent}% ডিসকাউন্ট কুপন`,
      active: true
    };

    const updated = [newC, ...editingCoupons];
    setEditingCoupons(updated);
    onUpdateCoupons(updated);

    setNewCouponCode('');
    setNewCouponDesc('');
    setShowAddCoupon(false);
    triggerSaveNotice(`কুপন কোড ${newC.code} তৈরি হয়েছে!`);
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['Order ID', 'Customer Name', 'Phone', 'Service', 'Quantity', 'Bill (BDT)', 'Payment', 'Payment Status', 'Order Status', 'Date', 'Time'];
    const rows = orders.map(o => [
      o.id,
      `"${o.name}"`,
      o.phone,
      `"${o.service}"`,
      `"${o.qty}"`,
      o.estimatedPrice,
      `"${o.payment}"`,
      `"${o.paymentStatus}"`,
      `"${o.status}"`,
      `"${o.date}"`,
      `"${o.time}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `print_point_orders_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export full JSON config
  const handleExportJSON = () => {
    const backup = {
      shopConfig,
      services,
      priceItems,
      coupons,
      orders,
      exportedAt: new Date().toISOString()
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backup, null, 2));
    const link = document.createElement('a');
    link.setAttribute('href', dataStr);
    link.setAttribute('download', `print_point_full_backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 bg-black/65 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full p-5 sm:p-7 shadow-2xl relative max-h-[92vh] overflow-y-auto border border-slate-200">
        
        {/* Close Button */}
        <button 
          onClick={onClose} 
          className="absolute right-4 top-4 p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {!isAuthenticated ? (
          /* LOGIN GATE */
          <div className="max-w-sm mx-auto py-8 text-center space-y-4">
            <div className="w-14 h-14 bg-[#031B4E] text-white rounded-2xl flex items-center justify-center mx-auto shadow-md">
              <Lock className="w-7 h-7 text-amber-400" />
            </div>

            <div>
              <h3 className="text-xl font-black text-[#031B4E]">ওনার / এডমিন কন্ট্রোল সেন্টার</h3>
              <p className="text-xs text-slate-500 mt-1">প্রিন্ট পয়েন্ট ওয়েবসাইট এডিটর ও ম্যানেজমেন্ট</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-3 pt-2 text-left">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  পাসওয়ার্ড লিখুন (ডিফল্ট: <span className="font-mono text-rose-600">admin123</span>)
                </label>
                <input
                  type="password"
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="••••••••"
                  className="w-full text-sm border border-slate-300 rounded-xl px-3.5 py-2.5 outline-none focus:ring-2 focus:ring-blue-600 font-mono"
                />
              </div>

              {loginError && (
                <p className="text-xs text-rose-600 font-semibold">{loginError}</p>
              )}

              <button
                type="submit"
                className="w-full bg-[#031B4E] hover:bg-[#0F4C81] text-white font-bold py-3 rounded-xl transition text-xs sm:text-sm shadow active:scale-95 cursor-pointer"
              >
                কন্ট্রোল প্যানেলে প্রবেশ করুন
              </button>
            </form>
          </div>
        ) : (
          /* AUTHENTICATED OWNER CONTROL PANEL */
          <div className="space-y-5">
            
            {/* Top Bar with Live Mode Indicator */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 bg-rose-600 text-white rounded-xl flex items-center justify-center">
                  <Store className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-[#031B4E]">
                    {shopConfig.shopName} - সাইট কন্ট্রোল সেন্টার
                  </h3>
                  <p className="text-[11px] text-slate-500">অনলাইনে ওয়েবসাইট নিয়ন্ত্রণ ও যেকোনো তথ্য সম্পাদনা</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[11px] bg-amber-50 text-amber-800 border border-amber-300 px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  ওনার এডিট মোড সচল
                </span>
                <button
                  onClick={handleLogout}
                  className="text-xs font-bold text-rose-600 hover:bg-rose-50 px-2.5 py-1 rounded-lg transition"
                >
                  লগআউট
                </button>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-slate-500 block text-[11px]">মোট অর্ডার</span>
                <span className="text-lg font-black text-[#031B4E]">{totalOrders}</span>
              </div>
              <div className="bg-amber-50 p-3 rounded-xl border border-amber-200">
                <span className="text-amber-800 block text-[11px]">নতুন গৃহীত</span>
                <span className="text-lg font-black text-amber-700">{pendingOrders}</span>
              </div>
              <div className="bg-blue-50 p-3 rounded-xl border border-blue-200">
                <span className="text-blue-800 block text-[11px]">কাজ চলছে</span>
                <span className="text-lg font-black text-blue-700">{processingOrders}</span>
              </div>
              <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200">
                <span className="text-emerald-800 block text-[11px]">সম্পন্ন</span>
                <span className="text-lg font-black text-emerald-700">{completedOrders}</span>
              </div>
              <div className="bg-purple-50 p-3 rounded-xl border border-purple-200 col-span-2 sm:col-span-1">
                <span className="text-purple-800 block text-[11px]">আনুমানিক আয়</span>
                <span className="text-lg font-black text-purple-700">৳{totalRevenue}</span>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="flex flex-wrap border-b border-slate-200 gap-1 sm:gap-2 text-xs font-bold">
              <button
                onClick={() => setActiveTab('orders')}
                className={`py-2 px-3 border-b-2 transition flex items-center gap-1.5 ${
                  activeTab === 'orders'
                    ? 'border-[#031B4E] text-[#031B4E]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Package className="w-3.5 h-3.5" />
                <span>অর্ডারসমূহ ({orders.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('site-content')}
                className={`py-2 px-3 border-b-2 transition flex items-center gap-1.5 ${
                  activeTab === 'site-content'
                    ? 'border-[#031B4E] text-[#031B4E]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <LayoutTemplate className="w-3.5 h-3.5" />
                <span>সাইটের লেখা ও ব্যানার এডিটর</span>
              </button>

              <button
                onClick={() => setActiveTab('services')}
                className={`py-2 px-3 border-b-2 transition flex items-center gap-1.5 ${
                  activeTab === 'services'
                    ? 'border-[#031B4E] text-[#031B4E]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <DollarSign className="w-3.5 h-3.5" />
                <span>সেবা ম্যানেজমেন্ট ({editingServices.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('price-items')}
                className={`py-2 px-3 border-b-2 transition flex items-center gap-1.5 ${
                  activeTab === 'price-items'
                    ? 'border-[#031B4E] text-[#031B4E]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>মূল্য তালিকা ({editingPriceItems.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('coupons')}
                className={`py-2 px-3 border-b-2 transition flex items-center gap-1.5 ${
                  activeTab === 'coupons'
                    ? 'border-[#031B4E] text-[#031B4E]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Tag className="w-3.5 h-3.5" />
                <span>অফার ও কুপন ({editingCoupons.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className={`py-2 px-3 border-b-2 transition flex items-center gap-1.5 ${
                  activeTab === 'settings'
                    ? 'border-[#031B4E] text-[#031B4E]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Settings className="w-3.5 h-3.5" />
                <span>দোকান সেটিংস ও পাসওয়ার্ড</span>
              </button>

              <button
                onClick={() => setActiveTab('export')}
                className={`py-2 px-3 border-b-2 transition flex items-center gap-1.5 ${
                  activeTab === 'export'
                    ? 'border-[#031B4E] text-[#031B4E]'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Download className="w-3.5 h-3.5" />
                <span>ব্যাকআপ</span>
              </button>
            </div>

            {savedNotice && (
              <div className="bg-emerald-100 border border-emerald-300 text-emerald-800 px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 animate-fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{savedNotice}</span>
              </div>
            )}

            {/* TAB 1: ORDERS */}
            {activeTab === 'orders' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                  <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
                    {['সব', 'গৃহীত', 'কাজ চলছে', 'প্রস্তুত', 'সম্পন্ন', 'বাতিল'].map((st) => (
                      <button
                        key={st}
                        onClick={() => setStatusFilter(st)}
                        className={`px-2.5 py-1 rounded-lg font-bold transition ${
                          statusFilter === st
                            ? 'bg-[#031B4E] text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>

                  <div className="relative w-full sm:w-64">
                    <input
                      type="text"
                      placeholder="অর্ডার আইডি, ফোন বা নাম..."
                      value={orderSearch}
                      onChange={(e) => setOrderSearch(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-3 pr-8 py-1.5 outline-none focus:ring-2 focus:ring-blue-600 text-xs"
                    />
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
                  </div>
                </div>

                <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                  {filteredOrders.length > 0 ? (
                    filteredOrders.map((order) => (
                      <div
                        key={order.id}
                        className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm hover:border-blue-400 transition flex flex-col md:flex-row justify-between items-start md:items-center gap-3 text-xs"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                              {order.id}
                            </span>
                            <span className="font-bold text-slate-900 text-sm">{order.name}</span>
                            <span className="text-slate-400">({order.phone})</span>
                          </div>

                          <div className="text-slate-600">
                            <strong>{order.service}</strong> | পরিমাণ: {order.qty} | বিল: <strong className="text-emerald-700">৳{order.estimatedPrice}</strong>
                          </div>

                          <div className="text-[11px] text-slate-500 flex flex-wrap gap-2">
                            <span>পেমেন্ট: {order.payment}</span>
                            <span>•</span>
                            <span className={order.paymentStatus === 'পরিশোধিত' ? 'text-emerald-600 font-bold' : 'text-amber-600 font-bold'}>
                              {order.paymentStatus}
                            </span>
                            <span>•</span>
                            <span>ডেলিভারি: {order.deliveryType}</span>
                            {order.fileName && (
                              <>
                                <span>•</span>
                                <span className="text-blue-600 font-semibold">ফাইল: {order.fileName}</span>
                              </>
                            )}
                          </div>

                          {order.notes && (
                            <p className="text-[11px] text-slate-500 italic bg-slate-50 p-1.5 rounded">
                              নোট: {order.notes}
                            </p>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-1.5 shrink-0 w-full md:w-auto justify-end">
                          <select
                            value={order.status}
                            onChange={(e) => onUpdateOrderStatus(order.id, e.target.value as OrderStatus)}
                            className="bg-slate-100 border border-slate-300 rounded-lg px-2 py-1 font-bold text-xs outline-none focus:ring-1 focus:ring-blue-600"
                          >
                            <option value="গৃহীত">গৃহীত</option>
                            <option value="কাজ চলছে">কাজ চলছে</option>
                            <option value="প্রস্তুত">প্রস্তুত</option>
                            <option value="সম্পন্ন">সম্পন্ন</option>
                            <option value="বাতিল">বাতিল</option>
                          </select>

                          <button
                            type="button"
                            onClick={() => onUpdatePaymentStatus(order.id, order.paymentStatus === 'পরিশোধিত' ? 'বকেয়া' : 'পরিশোধিত')}
                            className={`px-2 py-1 rounded-lg text-[11px] font-bold border transition ${
                              order.paymentStatus === 'পরিশোধিত'
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                                : 'bg-amber-50 text-amber-700 border-amber-300'
                            }`}
                          >
                            {order.paymentStatus === 'পরিশোধিত' ? 'পরিশোধিত ✓' : 'বকেয়া'}
                          </button>

                          <a
                            href={`tel:${order.phone}`}
                            className="p-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-lg transition"
                            title="কল করুন"
                          >
                            <Phone className="w-3.5 h-3.5" />
                          </a>

                          <a
                            href={`https://wa.me/88${order.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                              `আসসালামু আলাইকুম ${order.name}, প্রিন্ট পয়েন্ট থেকে আপনার অর্ডার #${order.id} (${order.service}) সংক্রান্ত বার্তা:`
                            )}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg transition"
                            title="WhatsApp চ্যাট"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </a>

                          <button
                            type="button"
                            onClick={() => onPrintOrder(order)}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition"
                            title="ক্যাশ মেমো প্রিন্ট করুন"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm(`অর্ডার #${order.id} কি মুছে ফেলতে চান?`)) {
                                onDeleteOrder(order.id);
                              }
                            }}
                            className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg transition"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-10 text-slate-400">
                      কোনো অর্ডার পাওয়া যায়নি!
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB 2: SITE CONTENT & HERO BANNER EDITOR */}
            {activeTab === 'site-content' && (
              <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
                <div className="bg-blue-50 p-3.5 rounded-xl border border-blue-200 text-blue-900">
                  <p className="font-bold flex items-center gap-1.5">
                    <Edit3 className="w-4 h-4 text-blue-700" />
                    <span>সাইটের হোমপেজের লেখা ও ব্যানার পরিবর্তন করুন:</span>
                  </p>
                  <p className="text-[11px] text-blue-700 mt-0.5">
                    এখানে যেকোনো তথ্য পরিবর্তন করে "পরিবর্তন সেভ করুন" বাটনে ক্লিক করলেই ওয়েবসাইটে সরাসরি আপডেট হয়ে যাবে।
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">দোকানের নাম (Header Logo)</label>
                    <input
                      type="text"
                      value={configForm.shopName}
                      onChange={(e) => setConfigForm({ ...configForm, shopName: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">ট্যাগলাইন / সাব-টাইটেল</label>
                    <input
                      type="text"
                      value={configForm.tagline}
                      onChange={(e) => setConfigForm({ ...configForm, tagline: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">জরুরি নোটিশ ব্যানার (সাইটের একদম উপরে)</label>
                  <input
                    type="text"
                    value={configForm.noticeBanner}
                    onChange={(e) => setConfigForm({ ...configForm, noticeBanner: e.target.value })}
                    className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">হিরো ব্যানার ছোট ব্যাজ</label>
                    <input
                      type="text"
                      value={configForm.heroBadge}
                      onChange={(e) => setConfigForm({ ...configForm, heroBadge: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">হিরো হাইলাইট টেক্সট (হলুদ লেখা)</label>
                    <input
                      type="text"
                      value={configForm.heroHighlight}
                      onChange={(e) => setConfigForm({ ...configForm, heroHighlight: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">হিরো প্রধান শিরোনাম (বড় লেখা)</label>
                  <input
                    type="text"
                    value={configForm.heroTitle}
                    onChange={(e) => setConfigForm({ ...configForm, heroTitle: e.target.value })}
                    className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">হিরো ব্যানারের বিস্তারিত বর্ণনা</label>
                  <textarea
                    rows={2}
                    value={configForm.heroSubtitle}
                    onChange={(e) => setConfigForm({ ...configForm, heroSubtitle: e.target.value })}
                    className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                  ></textarea>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">সপ্তাহের দিন (যেমন: শনিবার - শুক্রবার)</label>
                    <input
                      type="text"
                      value={configForm.weeklyDays}
                      onChange={(e) => setConfigForm({ ...configForm, weeklyDays: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">দোকানের কাজের সময়</label>
                    <input
                      type="text"
                      value={configForm.openingHours}
                      onChange={(e) => setConfigForm({ ...configForm, openingHours: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="bg-[#031B4E] hover:bg-[#0F4C81] text-white px-6 py-3 rounded-xl font-black flex items-center gap-2 shadow-lg transition active:scale-95 cursor-pointer"
                >
                  <Save className="w-4 h-4 text-amber-400" />
                  <span>পরিবর্তন সেভ করুন</span>
                </button>
              </form>
            )}

            {/* TAB 3: SERVICES MANAGEMENT (ADD, EDIT, DELETE) */}
            {activeTab === 'services' && (
              <div className="space-y-4 text-xs">
                <div className="flex flex-wrap justify-between items-center gap-2">
                  <p className="text-slate-500">
                    এখানে যেকোনো সেবার বিবরণ ও মূল্য সম্পাদন করতে পারেন অথবা নতুন সেবা যোগ করতে পারেন
                  </p>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddService(!showAddService)}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-lg font-bold flex items-center gap-1 shadow cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>নতুন সেবা যোগ করুন</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveServices}
                      className="bg-[#031B4E] hover:bg-[#0F4C81] text-white px-3.5 py-1.5 rounded-lg font-bold flex items-center gap-1 shadow cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5 text-amber-400" />
                      <span>সেভ করুন</span>
                    </button>
                  </div>
                </div>

                {/* Add Service Box */}
                {showAddService && (
                  <form onSubmit={handleAddNewService} className="bg-emerald-50/70 border border-emerald-200 p-4 rounded-2xl space-y-3">
                    <h4 className="font-bold text-emerald-900 flex items-center gap-1.5">
                      <Plus className="w-4 h-4 text-emerald-700" />
                      <span>নতুন সেবা যুক্ত করার ফরম</span>
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">সেবার নাম *</label>
                        <input
                          type="text"
                          required
                          placeholder="যেমন: পাসপোর্ট ফি চালান ও আবেদন"
                          value={newServiceTitle}
                          onChange={(e) => setNewServiceTitle(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-lg p-2"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">ক্যাটাগরি</label>
                        <select
                          value={newServiceCategory}
                          onChange={(e) => setNewServiceCategory(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-lg p-2"
                        >
                          <option value="অনলাইন সেবা">অনলাইন সেবা</option>
                          <option value="ছবি ও ল্যাব">ছবি ও ল্যাব</option>
                          <option value="প্রিন্ট ও কপি">প্রিন্ট ও কপি</option>
                          <option value="সরকারি সেবা">সরকারি সেবা</option>
                          <option value="টাইপিং ও ড্রাফটিং">টাইপিং ও ড্রাফটিং</option>
                          <option value="ডিজিটাল সার্ভিস">ডিজিটাল সার্ভিস</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">প্রারম্ভিক মূল্য (টাকা)</label>
                        <input
                          type="number"
                          placeholder="50"
                          value={newServicePrice}
                          onChange={(e) => setNewServicePrice(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-lg p-2"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">ডেলিভারির সময়</label>
                        <input
                          type="text"
                          placeholder="১০-১৫ মিনিট"
                          value={newServiceTime}
                          onChange={(e) => setNewServiceTime(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-lg p-2"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">সংক্ষিপ্ত বিবরণ</label>
                        <input
                          type="text"
                          placeholder="সেবার সংক্ষিপ্ত বিবরণ লিখুন..."
                          value={newServiceDesc}
                          onChange={(e) => setNewServiceDesc(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-lg p-2"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setShowAddService(false)}
                        className="px-3 py-1.5 bg-slate-200 text-slate-700 rounded-lg font-bold"
                      >
                        বাতিল
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg font-bold shadow"
                      >
                        যোগ করুন
                      </button>
                    </div>
                  </form>
                )}

                {/* Service Cards List */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-96 overflow-y-auto pr-1">
                  {editingServices.map((srv, idx) => (
                    <div key={srv.id} className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-xs space-y-2">
                      <div className="flex justify-between items-start gap-2">
                        <input
                          type="text"
                          value={srv.title}
                          onChange={(e) => handleServiceChange(idx, 'title', e.target.value)}
                          className="font-bold text-slate-800 bg-white border border-slate-300 px-2 py-1 rounded w-full"
                        />
                        <button
                          type="button"
                          onClick={() => handleDeleteService(srv.id, srv.title)}
                          className="text-rose-500 hover:text-rose-700 p-1 shrink-0"
                          title="মুছে ফেলুন"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <span className="text-slate-400 text-[10px] block">শুরুর মূল্য (৳)</span>
                          <input
                            type="number"
                            value={srv.startingPrice}
                            onChange={(e) => handleServiceChange(idx, 'startingPrice', parseInt(e.target.value) || 0)}
                            className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-bold"
                          />
                        </div>
                        <div>
                          <span className="text-slate-400 text-[10px] block">সময়</span>
                          <input
                            type="text"
                            value={srv.estimatedTime}
                            onChange={(e) => handleServiceChange(idx, 'estimatedTime', e.target.value)}
                            className="w-full px-2 py-1 bg-white border border-slate-300 rounded"
                          />
                        </div>
                      </div>

                      <div>
                        <span className="text-slate-400 text-[10px] block">বিবরণ</span>
                        <textarea
                          rows={2}
                          value={srv.description}
                          onChange={(e) => handleServiceChange(idx, 'description', e.target.value)}
                          className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-[11px]"
                        ></textarea>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: PRICE TABLE ITEMS */}
            {activeTab === 'price-items' && (
              <div className="space-y-4 text-xs">
                <div className="flex justify-between items-center">
                  <p className="text-slate-500">
                    মূল্য তালিকার প্রতিটি আইটেমের রেট ও বিবরণ এখান থেকে এডিট করতে পারবেন
                  </p>
                  <button
                    type="button"
                    onClick={() => setShowAddPriceItem(!showAddPriceItem)}
                    className="bg-[#031B4E] hover:bg-[#0F4C81] text-white px-3 py-1.5 rounded-lg font-bold flex items-center gap-1 shadow cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>নতুন রেট যোগ করুন</span>
                  </button>
                </div>

                {showAddPriceItem && (
                  <form onSubmit={handleAddPriceItem} className="bg-slate-100 p-3.5 rounded-xl border border-slate-300 space-y-2">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input
                        type="text"
                        required
                        placeholder="সেবার নাম (যেমন: A3 কালার প্রিন্ট)"
                        value={newPriceName}
                        onChange={(e) => setNewPriceName(e.target.value)}
                        className="bg-white border rounded p-1.5"
                      />
                      <input
                        type="text"
                        required
                        placeholder="মূল্য (যেমন: ৳ ৩০ / পাতা)"
                        value={newPriceRate}
                        onChange={(e) => setNewPriceRate(e.target.value)}
                        className="bg-white border rounded p-1.5"
                      />
                      <input
                        type="text"
                        placeholder="ক্যাটাগরি (যেমন: কালার প্রিন্ট)"
                        value={newPriceCat}
                        onChange={(e) => setNewPriceCat(e.target.value)}
                        className="bg-white border rounded p-1.5"
                      />
                    </div>
                    <div className="flex justify-between items-center">
                      <input
                        type="text"
                        placeholder="নোট বা শর্ত (ঐচ্ছিক)"
                        value={newPriceNote}
                        onChange={(e) => setNewPriceNote(e.target.value)}
                        className="bg-white border rounded p-1.5 w-3/4"
                      />
                      <button type="submit" className="bg-emerald-600 text-white px-3 py-1.5 rounded font-bold">
                        যুক্ত করুন
                      </button>
                    </div>
                  </form>
                )}

                <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                  {editingPriceItems.map((item, idx) => (
                    <div key={item.id} className="bg-white p-2.5 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-2">
                      <div className="flex-1 min-w-[200px]">
                        <input
                          type="text"
                          value={item.name}
                          onChange={(e) => {
                            const updated = [...editingPriceItems];
                            updated[idx].name = e.target.value;
                            setEditingPriceItems(updated);
                            onUpdatePriceItems(updated);
                          }}
                          className="font-bold text-slate-800 bg-transparent outline-none w-full border-b border-dashed border-slate-300"
                        />
                      </div>
                      <div className="w-32">
                        <input
                          type="text"
                          value={item.price}
                          onChange={(e) => {
                            const updated = [...editingPriceItems];
                            updated[idx].price = e.target.value;
                            setEditingPriceItems(updated);
                            onUpdatePriceItems(updated);
                          }}
                          className="font-black text-[#031B4E] bg-slate-50 border border-slate-200 rounded px-2 py-0.5 text-center w-full"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDeletePriceItem(item.id)}
                        className="text-rose-500 hover:text-rose-700 p-1"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 5: COUPONS & STOREWIDE DISCOUNTS */}
            {activeTab === 'coupons' && (
              <div className="space-y-4 text-xs">
                {/* Global Storewide Discount Card */}
                <div className="bg-gradient-to-r from-rose-50 to-amber-50 p-4 rounded-2xl border-2 border-rose-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h4 className="font-black text-rose-950 text-sm flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-rose-600" />
                        <span>সাইটব্যাপী সরাসরি ডিসকাউন্ট (Storewide Instant Discount)</span>
                      </h4>
                      <p className="text-[11px] text-rose-800 mt-0.5">
                        এটি অন করলে ওয়েবসাইটের সকল সেবায় স্বয়ংক্রিয়ভাবে ডিসকাউন্ট প্রযোজ্য হবে এবং হিরো ব্যানারে প্রদর্শিত হবে
                      </p>
                    </div>

                    <label className="flex items-center gap-2 font-bold cursor-pointer bg-white px-3 py-1.5 rounded-xl border border-rose-300 shadow-sm">
                      <input
                        type="checkbox"
                        checked={configForm.globalDiscountActive}
                        onChange={(e) => {
                          const updated = { ...configForm, globalDiscountActive: e.target.checked };
                          setConfigForm(updated);
                          onUpdateShopConfig(updated);
                          triggerSaveNotice(e.target.checked ? 'সাইটব্যাপী ডিসকাউন্ট চালু করা হয়েছে!' : 'ডিসকাউন্ট বন্ধ করা হয়েছে!');
                        }}
                        className="w-4 h-4 rounded text-rose-600"
                      />
                      <span className={configForm.globalDiscountActive ? 'text-emerald-700' : 'text-slate-500'}>
                        {configForm.globalDiscountActive ? 'ডিসকাউন্ট চালু আছে ✓' : 'ডিসকাউন্ট বন্ধ'}
                      </span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">ডিসকাউন্ট শতকরা (%)</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          value={configForm.globalDiscountPercent}
                          onChange={(e) => {
                            const val = parseInt(e.target.value) || 0;
                            const updated = { ...configForm, globalDiscountPercent: val };
                            setConfigForm(updated);
                          }}
                          className="w-24 bg-white border border-slate-300 rounded-xl p-2 font-black text-base text-rose-600"
                        />
                        <span className="font-bold text-slate-600">% ছাড়</span>
                      </div>
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 mb-1">ডিসকাউন্ট ব্যানার টেক্সট</label>
                      <input
                        type="text"
                        value={configForm.globalDiscountText}
                        onChange={(e) => {
                          const updated = { ...configForm, globalDiscountText: e.target.value };
                          setConfigForm(updated);
                        }}
                        placeholder="যেমন: সকল সেবায় আকর্ষণীয় ২০% ছাড়"
                        className="w-full bg-white border border-slate-300 rounded-xl p-2"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        onUpdateShopConfig(configForm);
                        triggerSaveNotice('ডিসকাউন্ট সেটিংস আপডেট হয়েছে!');
                      }}
                      className="bg-rose-600 hover:bg-rose-700 text-white font-bold px-4 py-1.5 rounded-xl transition shadow flex items-center gap-1.5 cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>ডিসকাউন্ট সেভ করুন</span>
                    </button>
                  </div>
                </div>

                {/* Custom Coupons Manager */}
                <div className="flex justify-between items-center pt-2">
                  <p className="text-slate-600 font-bold">
                    কাস্টম কুপন কোডসমূহ:
                  </p>
                  <button
                    type="button"
                    onClick={() => setShowAddCoupon(!showAddCoupon)}
                    className="bg-[#031B4E] hover:bg-[#0F4C81] text-white px-3 py-1.5 rounded-lg font-bold flex items-center gap-1 shadow cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>নতুন কুপন কোড বানান</span>
                  </button>
                </div>

                {showAddCoupon && (
                  <form onSubmit={handleAddCoupon} className="bg-amber-50 p-3.5 rounded-xl border border-amber-200 space-y-2">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input
                        type="text"
                        required
                        placeholder="কুপন কোড (যেমন: EID20)"
                        value={newCouponCode}
                        onChange={(e) => setNewCouponCode(e.target.value)}
                        className="bg-white border rounded p-1.5 uppercase font-mono font-bold"
                      />
                      <input
                        type="number"
                        placeholder="ডিসকাউন্ট % (যেমন: 20)"
                        value={newCouponPercent}
                        onChange={(e) => setNewCouponPercent(e.target.value)}
                        className="bg-white border rounded p-1.5 font-bold"
                      />
                      <input
                        type="number"
                        placeholder="সর্বোচ্চ ছাড় টাকা (যেমন: 100)"
                        value={newCouponMax}
                        onChange={(e) => setNewCouponMax(e.target.value)}
                        className="bg-white border rounded p-1.5"
                      />
                    </div>
                    <div className="flex justify-between items-center">
                      <input
                        type="text"
                        placeholder="কুপনের বিবরণ লিখুন..."
                        value={newCouponDesc}
                        onChange={(e) => setNewCouponDesc(e.target.value)}
                        className="bg-white border rounded p-1.5 w-3/4"
                      />
                      <button type="submit" className="bg-amber-600 text-white px-3.5 py-1.5 rounded font-bold">
                        তৈরি করুন
                      </button>
                    </div>
                  </form>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {editingCoupons.map((c, idx) => (
                    <div key={c.code} className="bg-white p-3 rounded-xl border border-slate-200 flex justify-between items-center">
                      <div>
                        <div className="font-mono font-black text-rose-600 text-sm">{c.code}</div>
                        <div className="text-slate-600">{c.description} ({c.discountPercent}% ছাড়)</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const updated = editingCoupons.filter((_, i) => i !== idx);
                          setEditingCoupons(updated);
                          onUpdateCoupons(updated);
                        }}
                        className="text-rose-500 hover:text-rose-700 p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 6: SHOP SETTINGS & PASSWORDS */}
            {activeTab === 'settings' && (
              <form onSubmit={handleSaveSettings} className="space-y-3.5 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">দোকানের মোবাইল নম্বর</label>
                    <input
                      type="text"
                      value={configForm.phone}
                      onChange={(e) => setConfigForm({ ...configForm, phone: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">হোয়াটসঅ্যাপ নম্বর (৮৮০...)</label>
                    <input
                      type="text"
                      value={configForm.whatsapp}
                      onChange={(e) => setConfigForm({ ...configForm, whatsapp: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">বিকাশ পার্সোনাল নম্বর</label>
                    <input
                      type="text"
                      value={configForm.bkashNumber}
                      onChange={(e) => setConfigForm({ ...configForm, bkashNumber: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">নগদ পার্সোনাল নম্বর</label>
                    <input
                      type="text"
                      value={configForm.nagadNumber}
                      onChange={(e) => setConfigForm({ ...configForm, nagadNumber: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">দোকানের ঠিকানা</label>
                    <input
                      type="text"
                      value={configForm.address}
                      onChange={(e) => setConfigForm({ ...configForm, address: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">এডমিন পাসওয়ার্ড পরিবর্তন</label>
                    <input
                      type="text"
                      value={configForm.adminPassword}
                      onChange={(e) => setConfigForm({ ...configForm, adminPassword: e.target.value })}
                      className="w-full border rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600 font-mono font-bold"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="bg-[#031B4E] hover:bg-[#0F4C81] text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-1.5 shadow cursor-pointer"
                >
                  <Save className="w-4 h-4 text-amber-400" />
                  <span>সেটিংস সংরক্ষণ করুন</span>
                </button>
              </form>
            )}

            {/* TAB 7: EXPORT & DATA BACKUP */}
            {activeTab === 'export' && (
              <div className="space-y-4 text-xs">
                <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
                  <h4 className="font-bold text-slate-800 text-sm">এক্সেল / CSV ডাউনলোড</h4>
                  <p className="text-slate-500">
                    সবগুলো গ্রাহকের অর্ডারের বিবরণ, ফোন নম্বর, সেবামূল্য ও তারিখ এক্সেলে ব্যাকআপ নিতে নিচের বাটনে ক্লিক করুন।
                  </p>
                  <button
                    onClick={handleExportCSV}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl transition flex items-center gap-1.5 shadow cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>CSV / Excel ফাইল ডাউনলোড করুন</span>
                  </button>
                </div>

                <div className="bg-amber-50 p-5 rounded-2xl border border-amber-200 space-y-3">
                  <h4 className="font-bold text-amber-900 text-sm">ওয়েবসাইটের সম্পূর্ণ কনফিগ ব্যাকআপ (JSON)</h4>
                  <p className="text-amber-800">
                    আপনার এডিট করা সমস্ত টেক্সট, নতুন সেবা, মূল্যতালিকা ও অর্ডার ব্যাকআপ ফাইল হিসেবে ডাউনলোড করে রাখতে পারেন:
                  </p>
                  <button
                    onClick={handleExportJSON}
                    className="bg-amber-600 hover:bg-amber-700 text-white font-bold px-4 py-2 rounded-xl transition flex items-center gap-1.5 shadow cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>সম্পূর্ণ সাইট কনফিগ ডাউনলোড করুন (JSON)</span>
                  </button>
                </div>
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
};
