import React, { useState, useEffect } from 'react';
import { 
  X, 
  ShoppingCart, 
  MessageCircle, 
  Upload, 
  CheckCircle2, 
  Clock, 
  Tag, 
  ShieldCheck, 
  Copy, 
  FileText,
  CreditCard,
  Building,
  Check,
  PhoneCall,
  Sparkles
} from 'lucide-react';
import { Order, ServiceItem, ShopConfig, Coupon } from '../types';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  services: ServiceItem[];
  shopConfig: ShopConfig;
  coupons: Coupon[];
  prefill?: {
    serviceName: string;
    qty?: string;
    estimatedPrice?: number;
    notes?: string;
    urgent?: boolean;
    coupon?: string;
  } | null;
  onOrderCreated: (newOrder: Order) => void;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  services,
  shopConfig,
  coupons,
  prefill,
  onOrderCreated
}) => {
  const [selectedService, setSelectedService] = useState<string>(services[0]?.title || '');
  const [custName, setCustName] = useState<string>('');
  const [custPhone, setCustPhone] = useState<string>('');
  const [custQty, setCustQty] = useState<string>('১ টি');
  const [custNotes, setCustNotes] = useState<string>('');
  const [custPayment, setCustPayment] = useState<string>('দোকানে এসে ক্যাশ (Cash on Delivery)');
  const [deliveryType, setDeliveryType] = useState<Order['deliveryType']>('দোকান থেকে সংগ্রহ');
  const [urgent, setUrgent] = useState<boolean>(false);
  const [attachedFileName, setAttachedFileName] = useState<string>('');
  const [couponInput, setCouponInput] = useState<string>('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  
  // Submission result state
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);
  const [copiedId, setCopiedId] = useState<boolean>(false);

  // Sync prefill values
  useEffect(() => {
    if (prefill) {
      if (prefill.serviceName) setSelectedService(prefill.serviceName);
      if (prefill.qty) setCustQty(prefill.qty);
      if (prefill.notes) setCustNotes(prefill.notes);
      if (prefill.urgent !== undefined) setUrgent(prefill.urgent);
      if (prefill.coupon) {
        setCouponInput(prefill.coupon);
        const matched = coupons.find(c => c.code.toUpperCase() === prefill.coupon?.toUpperCase());
        if (matched) setAppliedCoupon(matched);
      }
    }
  }, [prefill, coupons]);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setAttachedFileName(e.target.files[0].name);
    }
  };

  const handleApplyCoupon = () => {
    const code = couponInput.trim().toUpperCase();
    const found = coupons.find(c => c.code.toUpperCase() === code && c.active);
    if (found) {
      setAppliedCoupon(found);
    } else {
      setAppliedCoupon(null);
    }
  };

  const calculateEstimate = () => {
    let base = 50;
    const s = services.find(x => x.title === selectedService);
    if (s) base = s.startingPrice;
    if (prefill?.estimatedPrice) base = prefill.estimatedPrice;

    // Apply global shop discount if active
    if (shopConfig.globalDiscountActive && shopConfig.globalDiscountPercent > 0) {
      const gDiscount = Math.round(base * (shopConfig.globalDiscountPercent / 100));
      base = Math.max(10, base - gDiscount);
    }

    if (urgent) base += 25;
    if (appliedCoupon) {
      const discount = Math.min(Math.round(base * (appliedCoupon.discountPercent / 100)), appliedCoupon.maxDiscount);
      base -= discount;
    }
    return Math.max(base, 10);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!custName.trim() || !custPhone.trim()) {
      return;
    }

    const orderId = 'PP-' + Math.floor(1000 + Math.random() * 9000);
    const now = new Date();
    const dateStr = now.toLocaleDateString('bn-BD', { day: '2-digit', month: 'long', year: 'numeric' });
    const timeStr = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });

    const newOrder: Order = {
      id: orderId,
      service: selectedService,
      category: services.find(s => s.title === selectedService)?.category || 'সাধারণ সেবা',
      name: custName.trim(),
      phone: custPhone.trim(),
      qty: custQty.trim() || '১ টি',
      notes: custNotes.trim() || 'কোনো বিশেষ নির্দেশ নেই',
      payment: custPayment,
      paymentStatus: 'বকেয়া',
      status: 'গৃহীত',
      date: dateStr,
      time: timeStr,
      estimatedPrice: calculateEstimate(),
      deliveryType: deliveryType,
      urgent: urgent,
      fileName: attachedFileName || undefined,
      appliedCoupon: appliedCoupon ? appliedCoupon.code : undefined
    };

    onOrderCreated(newOrder);
    setCreatedOrder(newOrder);

    // Format WhatsApp message
    const waText = 
`*নতুন অনলাইন অর্ডার - ${shopConfig.shopName}*
--------------------------------
🆔 *অর্ডার আইডি:* ${orderId}
📌 *সেবা:* ${selectedService}
👤 *গ্রাহকের নাম:* ${newOrder.name}
📞 *মোবাইল:* ${newOrder.phone}
🔢 *পরিমাণ / কপি:* ${newOrder.qty}
🚚 *ডেলিভারি ধরন:* ${newOrder.deliveryType}
⚡ *জরুরি অর্ডার:* ${urgent ? 'হ্যাঁ (Urgent)' : 'স্বাভাবিক'}
💳 *পেমেন্ট:* ${newOrder.payment}
💰 *আনুমানিক বিল:* ৳ ${newOrder.estimatedPrice}
${attachedFileName ? `📎 *ফাইল সংযুক্ত:* ${attachedFileName}\n` : ''}${appliedCoupon ? `🏷️ *কুপন কোড:* ${appliedCoupon.code}\n` : ''}📝 *নির্দেশনা:* ${newOrder.notes}
--------------------------------
_আমি এই অর্ডারটি কনফার্ম করতে চাচ্ছি। দয়া করে কাজের বিস্তারিত চেক করে কনফার্ম করুন।_`;

    const encoded = encodeURIComponent(waText);
    const waUrl = `https://wa.me/${shopConfig.whatsapp}?text=${encoded}`;

    // Open WhatsApp in new tab
    window.open(waUrl, '_blank');
  };

  const handleCopyOrderId = () => {
    if (createdOrder) {
      navigator.clipboard.writeText(createdOrder.id);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handleResetAndClose = () => {
    setCreatedOrder(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/65 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full p-5 sm:p-7 shadow-2xl relative max-h-[92vh] overflow-y-auto border border-slate-200">
        
        {/* Close Button */}
        <button 
          onClick={handleResetAndClose} 
          className="absolute right-4 top-4 p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {createdOrder ? (
          /* SUCCESS STATE WITH DIRECT WHATSAPP CONFIRMATION */
          <div className="text-center py-4 space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto shadow-sm">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                অর্ডার সফলভাবে জমা হয়েছে!
              </span>
              <h3 className="text-2xl font-black text-[#031B4E] mt-2">
                ধন্যবাদ, {createdOrder.name}!
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                আপনার অর্ডারের বিবরণ আমাদের এডমিন ড্যাশবোর্ডে সংরক্ষিত হয়েছে।
              </p>
            </div>

            {/* Order Box */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left space-y-2">
              <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                <span className="text-xs text-slate-500 font-semibold">আপনার ট্র্যাকিং আইডি:</span>
                <div className="flex items-center gap-1.5">
                  <span className="font-mono text-base font-black text-rose-600">{createdOrder.id}</span>
                  <button
                    onClick={handleCopyOrderId}
                    className="p-1 hover:bg-slate-200 rounded text-slate-600 cursor-pointer"
                    title="কপি করুন"
                  >
                    {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div className="text-xs text-slate-700 space-y-1">
                <p><strong>সেবা:</strong> {createdOrder.service}</p>
                <p><strong>পরিমাণ:</strong> {createdOrder.qty}</p>
                <p><strong>আনুমানিক মূল্য:</strong> ৳ {createdOrder.estimatedPrice}</p>
                <p><strong>পেমেন্ট মাধ্যম:</strong> {createdOrder.payment}</p>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-left text-xs text-blue-900">
              <p className="font-bold flex items-center gap-1.5 mb-1">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>মালিকের সাথে সরাসরি WhatsApp যোগাযোগ:</span>
              </p>
              <p>দোকানের ওনার আপনার অর্ডারটি গ্রহণ করে সরাসরি WhatsApp-এ ফাইল ও কাজের অগ্রগতি নিশ্চিত করবেন।</p>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <a
                href={`https://wa.me/${shopConfig.whatsapp}?text=${encodeURIComponent(
                  `Hello Print Point, My Order ID is ${createdOrder.id} (${createdOrder.service}). Please confirm my order.`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3 rounded-xl transition text-xs sm:text-sm flex items-center justify-center gap-2 shadow"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp-এ সরাসরি কথা বলুন</span>
              </a>

              <button
                type="button"
                onClick={handleResetAndClose}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2.5 rounded-xl transition text-xs cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        ) : (
          /* FORM STATE */
          <div>
            <div className="flex items-center gap-2.5 mb-3">
              <div className="bg-rose-100 p-2.5 rounded-2xl text-rose-600">
                <ShoppingCart className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-black text-[#031B4E]">
                  সহজ অনলাইন অর্ডার ফরম
                </h3>
                <p className="text-[11px] text-slate-500">লগইন ছাড়াই সহজে অর্ডার করুন ও WhatsApp-এ কাজ বুঝে নিন</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              
              {/* Selected Service */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">নির্বাচিত সেবা *</label>
                <select
                  value={selectedService}
                  onChange={(e) => setSelectedService(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600 bg-white font-semibold text-slate-800"
                >
                  {services.map((s) => (
                    <option key={s.id} value={s.title}>
                      {s.title} (৳{s.startingPrice} {s.unit})
                    </option>
                  ))}
                  <option value="অন্যান্য কাস্টম কাজ">অন্যান্য কাস্টম কাজ / আলোচনা সাপেক্ষে</option>
                </select>
              </div>

              {/* Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">আপনার নাম *</label>
                  <input
                    type="text"
                    required
                    placeholder="আপনার পূর্ণ নাম লিখুন"
                    value={custName}
                    onChange={(e) => setCustName(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">মোবাইল নম্বর (WhatsApp) *</label>
                  <input
                    type="tel"
                    required
                    placeholder="018XXXXXXXX"
                    value={custPhone}
                    onChange={(e) => setCustPhone(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
              </div>

              {/* Quantity / Pages & File Attachment */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">কাজের পরিমাণ / পৃষ্ঠা সংখ্যা</label>
                  <input
                    type="text"
                    placeholder="যেমন: ৪ কপি ছবি / ২০ পাতা প্রিন্ট"
                    value={custQty}
                    onChange={(e) => setCustQty(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">ফাইল / ছবি সংযুক্ত করুন (ঐচ্ছিক)</label>
                  <label className="w-full border border-dashed border-slate-300 hover:border-blue-500 rounded-xl p-2 flex items-center justify-center gap-1.5 cursor-pointer bg-slate-50 transition">
                    <Upload className="w-3.5 h-3.5 text-slate-500" />
                    <span className="text-[11px] text-slate-600 truncate max-w-[130px]">
                      {attachedFileName || 'ফাইল সিলেক্ট করুন'}
                    </span>
                    <input type="file" onChange={handleFileChange} className="hidden" />
                  </label>
                </div>
              </div>

              {/* Delivery & Payment Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">ডেলিভারি মাধ্যম</label>
                  <select
                    value={deliveryType}
                    onChange={(e) => setDeliveryType(e.target.value as any)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600 bg-white"
                  >
                    <option value="দোকান থেকে সংগ্রহ">দোকান থেকে সংগ্রহ (মরিচা বাজার)</option>
                    <option value="অনলাইন ফাইল ডেলিভারি">অনলাইন ফাইল (WhatsApp / Email)</option>
                    <option value="জরুরি হোম ডেলিভারি">জরুরি হোম ডেলিভারি (উখিয়া এলাকা)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">পেমেন্ট মেথড (সহজ অপশন)</label>
                  <select
                    value={custPayment}
                    onChange={(e) => setCustPayment(e.target.value)}
                    className="w-full border border-slate-300 rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600 bg-white font-medium"
                  >
                    <option value="দোকানে এসে ক্যাশ (Cash on Delivery)">দোকানে এসে ক্যাশ পরিশোধ</option>
                    <option value="পরে আলোচনা সাপেক্ষে পেমেন্ট (WhatsApp Discussion)">পরে আলোচনা সাপেক্ষে পেমেন্ট</option>
                    <option value="বিকাশ পার্সোনাল সেন্ড মানি (01887922095)">বিকাশ পার্সোনাল (01887922095)</option>
                    <option value="নগদ পার্সোনাল সেন্ড মানি (01887922095)">নগদ পার্সোনাল (01887922095)</option>
                  </select>
                </div>
              </div>

              {/* Instructions */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">কাজের বিশেষ নির্দেশনা (ঐচ্ছিক)</label>
                <textarea
                  rows={2}
                  placeholder="কীভাবে কাজ করতে হবে বিস্তারিত লিখুন..."
                  value={custNotes}
                  onChange={(e) => setCustNotes(e.target.value)}
                  className="w-full border border-slate-300 rounded-xl p-2.5 outline-none focus:ring-2 focus:ring-blue-600"
                ></textarea>
              </div>

              {/* Urgent Toggle & Promo Code */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-1">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={urgent}
                    onChange={(e) => setUrgent(e.target.checked)}
                    className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500"
                  />
                  <span className="font-semibold text-slate-700 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-rose-600" />
                    জরুরি সার্ভিস (+৳ ২৫)
                  </span>
                </label>

                <div className="flex items-center gap-1.5 w-full sm:w-auto">
                  <input
                    type="text"
                    placeholder="কুপন (PRINT20)"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                    className="w-full sm:w-28 text-xs bg-slate-50 border border-slate-300 rounded-lg px-2 py-1 outline-none uppercase font-bold"
                  />
                  <button
                    type="button"
                    onClick={handleApplyCoupon}
                    className="bg-slate-800 text-white px-2.5 py-1 rounded-lg text-xs font-bold hover:bg-black transition shrink-0 cursor-pointer"
                  >
                    প্রয়োগ
                  </button>
                </div>
              </div>

              {/* Estimated Price summary */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-3 flex justify-between items-center text-xs">
                <div>
                  <span className="text-slate-600 block font-semibold">আনুমানিক প্রদেয় বিল:</span>
                  <span className="text-[11px] text-emerald-700 font-bold">
                    {shopConfig.globalDiscountActive ? `🔥 ${shopConfig.globalDiscountPercent}% স্পেশাল ডিসকাউন্ট প্রযোজ্য!` : 'কোনো গোপন চার্জ নেই'}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xl font-black text-[#031B4E]">
                    ৳ {calculateEstimate()}
                  </span>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3.5 rounded-2xl transition shadow-lg flex items-center justify-center gap-2 text-sm sm:text-base active:scale-95 cursor-pointer mt-1"
              >
                <MessageCircle className="w-5 h-5" />
                <span>অর্ডার কনফার্ম করুন ও WhatsApp-এ পাঠান</span>
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400 text-center pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>কোনো জটিল মার্চেন্ট গেটওয়ে লাগবে না—সরাসরি ওনারের সাথে যোগাযোগ করুন</span>
              </div>
            </form>
          </div>
        )}

      </div>
    </div>
  );
};
