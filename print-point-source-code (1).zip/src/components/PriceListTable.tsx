import React, { useState } from 'react';
import { Tag, Search, CheckCircle, ArrowRight } from 'lucide-react';
import { PriceTableItem } from '../types';

interface PriceListTableProps {
  priceItems: PriceTableItem[];
  onOrderService: (serviceName: string) => void;
}

export const PriceListTable: React.FC<PriceListTableProps> = ({ priceItems, onOrderService }) => {
  const [filterCat, setFilterCat] = useState<string>('সকল');
  const [tableSearch, setTableSearch] = useState<string>('');

  const categories = ['সকল', 'ফটোকপি', 'কালার প্রিন্ট', 'ছবি ল্যাব', 'টাইপিং & ডিজাইন', 'বাইন্ডিং', 'সরকারি সেবা'];

  const filteredItems = priceItems.filter((item) => {
    const matchesCat = filterCat === 'সকল' || item.category.includes(filterCat);
    const matchesText =
      !tableSearch ||
      item.name.toLowerCase().includes(tableSearch.toLowerCase()) ||
      item.category.toLowerCase().includes(tableSearch.toLowerCase());
    return matchesCat && matchesText;
  });

  return (
    <section id="price-list" className="bg-slate-100/70 py-16 border-y border-slate-200 scroll-mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-8">
          <span className="text-rose-600 font-bold text-xs uppercase tracking-widest bg-rose-50 px-3 py-1 rounded-full border border-rose-200">
            স্বচ্ছ ও সাশ্রয়ী দর
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-[#031B4E] mt-2">
            আমাদের পূর্ণাঙ্গ মূল্য তালিকা
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            সব সেবার সঠিক মূল্য জেনে অর্ডার করুন, কোনো গোপন অতিরিক্ত চার্জ নেই
          </p>

          {/* Table Filters */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mt-6">
            <div className="flex flex-wrap items-center justify-center gap-1.5">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setFilterCat(c)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                    filterCat === c
                      ? 'bg-[#031B4E] text-white shadow-sm'
                      : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-56">
              <input
                type="text"
                placeholder="তালিকায় খুঁজুন..."
                value={tableSearch}
                onChange={(e) => setTableSearch(e.target.value)}
                className="w-full text-xs bg-white border border-slate-200 rounded-lg pl-3 pr-8 py-2 outline-none focus:ring-2 focus:ring-blue-600"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>
        </div>

        {/* Table Card */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden border border-slate-200">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-[#031B4E] text-white text-xs uppercase tracking-wide">
                <tr>
                  <th className="py-3.5 px-4 sm:px-6">সেবার নাম ও বিবরণ</th>
                  <th className="py-3.5 px-4">ক্যাটাগরি</th>
                  <th className="py-3.5 px-4">মূল্য (আনুমানিক)</th>
                  <th className="py-3.5 px-4 text-center">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {filteredItems.map((item) => (
                  <tr key={item.id} className="hover:bg-blue-50/50 transition">
                    <td className="py-3.5 px-4 sm:px-6">
                      <div className="font-bold text-slate-900">{item.name}</div>
                      {item.note && (
                        <div className="text-[11px] text-slate-500 font-normal mt-0.5 flex items-center gap-1">
                          <span className="w-1 h-1 rounded-full bg-blue-500"></span>
                          <span>{item.note}</span>
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className="bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border border-slate-200">
                        {item.category}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className="text-[#031B4E] font-black text-sm">
                        {item.price}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <button 
                        onClick={() => onOrderService(item.name)} 
                        className="bg-[#0F4C81] hover:bg-[#031B4E] text-white px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 mx-auto shadow-sm active:scale-95"
                      >
                        <span>অর্ডার</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </section>
  );
};
