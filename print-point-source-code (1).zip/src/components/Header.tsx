import React, { useState } from 'react';
import { 
  Phone, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  Search, 
  Menu, 
  X, 
  Printer, 
  Sparkles, 
  Share2, 
  Lock, 
  MessageCircle,
  ExternalLink,
  Gift,
  HelpCircle
} from 'lucide-react';
import { ShopConfig } from '../types';
import { PrintPointLogo } from './PrintPointLogo';

interface HeaderProps {
  shopConfig: ShopConfig;
  onOpenOrderModal: (serviceName?: string) => void;
  onOpenAdminModal: () => void;
  onOpenShareModal: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  shopConfig,
  onOpenOrderModal,
  onOpenAdminModal,
  onOpenShareModal,
  searchQuery,
  setSearchQuery
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      {/* 1. TOP HEADER BAR matching reference */}
      <div className="bg-[#031B4E] text-white text-xs py-2 px-4 sm:px-8 border-b border-blue-900/60 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
          
          {/* Left Location & Phone */}
          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 text-slate-200">
            <span className="flex items-center gap-1.5 font-medium">
              <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
              <span>{shopConfig.address}</span>
            </span>
            <span className="hidden sm:inline text-blue-500">|</span>
            <a 
              href={`tel:${shopConfig.phone}`} 
              className="flex items-center gap-1.5 hover:text-amber-400 transition font-bold text-slate-100"
            >
              <Phone className="w-3.5 h-3.5 text-rose-400 shrink-0" />
              <span>{shopConfig.phone}</span>
            </a>
            <span className="hidden sm:inline text-blue-500">|</span>
            <a 
              href={`https://wa.me/${shopConfig.whatsapp}`} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex items-center gap-1.5 hover:text-emerald-300 transition text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>
          </div>

          {/* Right Links & Admin Button */}
          <div className="flex items-center gap-3 sm:gap-4">
            <a 
              href="#offers" 
              className="hover:text-amber-300 transition text-slate-300 flex items-center gap-1 text-xs"
            >
              <span>অফার & ডিসকাউন্ট 🎁</span>
            </a>

            <span className="text-blue-800">|</span>

            <a 
              href="#order-track" 
              className="hover:text-amber-300 transition text-slate-300 flex items-center gap-1 text-xs"
            >
              <Search className="w-3 h-3 text-cyan-400" />
              <span>আমার অর্ডার ট্র্যাক 🔍</span>
            </a>

            <span className="text-blue-800">|</span>

            <button 
              onClick={onOpenAdminModal}
              className="bg-rose-600 hover:bg-rose-700 text-white px-3 py-1 rounded-lg text-xs font-black transition flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
            >
              <Lock className="w-3 h-3" />
              <span>এডমিন লগইন</span>
            </button>
          </div>

        </div>
      </div>

      {/* 2. MAIN NAVBAR */}
      <nav className="bg-white sticky top-[33px] sm:top-[33px] z-40 shadow-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-3 flex items-center justify-between gap-4">
          
          {/* Brand Logo with dynamic custom icon */}
          <a href="#" className="flex items-center">
            <PrintPointLogo size="md" showTagline={true} />
          </a>

          {/* Desktop Nav Links */}
          <div className="hidden lg:flex items-center gap-2 font-bold text-sm">
            <a 
              href="#" 
              className="bg-rose-600 text-white px-4 py-1.5 rounded-full transition flex items-center gap-1.5 shadow-sm"
            >
              <span>হোম</span>
            </a>
            <a href="#services" className="text-slate-700 hover:text-rose-600 px-3 py-1.5 rounded-lg transition">
              সেবাসমূহ ▾
            </a>
            <a href="#price-list" className="text-slate-700 hover:text-rose-600 px-3 py-1.5 rounded-lg transition">
              মূল্য তালিকা ▾
            </a>
            <a href="#offers" className="text-slate-700 hover:text-rose-600 px-3 py-1.5 rounded-lg transition">
              ডিসকাউন্ট ▾
            </a>
            <a href="#contact" className="text-slate-700 hover:text-rose-600 px-3 py-1.5 rounded-lg transition">
              যোগাযোগ
            </a>
          </div>

          {/* Search Box & Mobile Menu */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Search Input Box with Blue button */}
            <div className="flex items-center border border-slate-300 rounded-lg overflow-hidden bg-white shadow-sm w-40 sm:w-60">
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="সেবা খুঁজুন..." 
                className="w-full bg-transparent text-slate-800 text-xs sm:text-sm pl-3 pr-2 py-1.5 outline-none placeholder:text-slate-400"
              />
              <button 
                type="button" 
                className="bg-[#031B4E] hover:bg-[#0F4C81] text-white p-2 transition"
                aria-label="Search"
              >
                <Search className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-700 hover:text-[#031B4E] focus:outline-none"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>

        {/* Mobile Drawer Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-t border-slate-100 px-6 py-4 space-y-3 font-semibold text-sm shadow-xl">
            <a 
              href="#" 
              onClick={() => setMobileMenuOpen(false)} 
              className="block text-rose-600 py-1 font-bold"
            >
              হোম
            </a>
            <a 
              href="#services" 
              onClick={() => setMobileMenuOpen(false)} 
              className="block text-slate-700 hover:text-rose-600 py-1"
            >
              সেবাসমূহ
            </a>
            <a 
              href="#price-list" 
              onClick={() => setMobileMenuOpen(false)} 
              className="block text-slate-700 hover:text-rose-600 py-1"
            >
              মূল্য তালিকা
            </a>
            <a 
              href="#offers" 
              onClick={() => setMobileMenuOpen(false)} 
              className="block text-slate-700 hover:text-rose-600 py-1"
            >
              অফার ও ডিসকাউন্ট
            </a>
            <a 
              href="#order-track" 
              onClick={() => setMobileMenuOpen(false)} 
              className="block text-slate-700 hover:text-rose-600 py-1"
            >
              অর্ডার ট্র্যাকিং
            </a>
            <a 
              href="#contact" 
              onClick={() => setMobileMenuOpen(false)} 
              className="block text-slate-700 hover:text-rose-600 py-1"
            >
              যোগাযোগ ও ঠিকানা
            </a>

            <div className="pt-2 flex flex-col gap-2">
              <button 
                onClick={() => { setMobileMenuOpen(false); onOpenOrderModal(); }} 
                className="w-full bg-rose-600 hover:bg-rose-700 text-white py-2.5 rounded-xl font-black text-xs shadow cursor-pointer"
              >
                এখনই অর্ডার করুন
              </button>
              <button 
                onClick={() => { setMobileMenuOpen(false); onOpenShareModal(); }} 
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-200 cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>সাইট লিংক শেয়ার করুন</span>
              </button>
            </div>
          </div>
        )}
      </nav>
    </>
  );
};
