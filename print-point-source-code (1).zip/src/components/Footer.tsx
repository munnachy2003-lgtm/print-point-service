import React from 'react';
import { 
  Printer, 
  MapPin, 
  Phone, 
  MessageCircle, 
  Mail, 
  Heart, 
  Lock, 
  Share2 
} from 'lucide-react';
import { ShopConfig } from '../types';
import { PrintPointLogo } from './PrintPointLogo';

interface FooterProps {
  shopConfig: ShopConfig;
  onOpenAdminModal: () => void;
  onOpenShareModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ shopConfig, onOpenAdminModal, onOpenShareModal }) => {
  return (
    <footer className="bg-[#031B4E] text-white border-t-4 border-rose-600 pt-8 pb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        
        {/* Main Footer Row matching mockup */}
        <div className="flex flex-col lg:flex-row justify-between items-center gap-6 pb-6 border-b border-blue-900/60">
          
          {/* Logo & Tagline */}
          <div className="flex items-center gap-3">
            <PrintPointLogo size="md" theme="dark" showTagline={true} />
          </div>

          {/* Contact Details in middle */}
          <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 text-xs text-slate-200">
            <span className="flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-rose-500 shrink-0" />
              <span>{shopConfig.address}</span>
            </span>

            <a href={`tel:${shopConfig.phone}`} className="flex items-center gap-1.5 hover:text-amber-400 transition font-bold">
              <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{shopConfig.phone}</span>
            </a>

            <a href={`mailto:${shopConfig.email}`} className="flex items-center gap-1.5 hover:text-amber-400 transition">
              <Mail className="w-4 h-4 text-blue-400 shrink-0" />
              <span>{shopConfig.email}</span>
            </a>
          </div>

          {/* Social Icons matching mockup */}
          <div className="flex items-center gap-2">
            {/* Facebook */}
            <a 
              href="https://facebook.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-8 h-8 rounded-full bg-blue-600 hover:bg-blue-700 flex items-center justify-center text-white transition shadow"
              title="Facebook"
            >
              <span className="font-black text-xs">f</span>
            </a>

            {/* YouTube */}
            <a 
              href="https://youtube.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-8 h-8 rounded-full bg-red-600 hover:bg-red-700 flex items-center justify-center text-white transition shadow"
              title="YouTube"
            >
              <span className="font-black text-xs">▶</span>
            </a>

            {/* Messenger / WhatsApp */}
            <a 
              href={`https://wa.me/${shopConfig.whatsapp}`} 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-8 h-8 rounded-full bg-blue-500 hover:bg-blue-600 flex items-center justify-center text-white transition shadow"
              title="Messenger / WhatsApp"
            >
              <MessageCircle className="w-4 h-4 text-white" />
            </a>

            {/* LinkedIn */}
            <a 
              href="https://linkedin.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-8 h-8 rounded-full bg-blue-700 hover:bg-blue-800 flex items-center justify-center text-white transition shadow"
              title="LinkedIn"
            >
              <span className="font-black text-xs">in</span>
            </a>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-4 flex flex-col sm:flex-row justify-between items-center gap-3 text-[11px] text-slate-400">
          <div>
            &copy; ২০২৬ {shopConfig.shopName}. সর্বস্বত্ব সংরক্ষিত। পরিচালক: {shopConfig.ownerName}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onOpenShareModal}
              className="hover:text-amber-300 transition flex items-center gap-1 cursor-pointer"
            >
              <Share2 className="w-3 h-3" />
              <span>সাইট লিংক</span>
            </button>
            <span>|</span>
            <button
              onClick={onOpenAdminModal}
              className="hover:text-rose-400 transition flex items-center gap-1 cursor-pointer font-bold"
            >
              <Lock className="w-3 h-3" />
              <span>ওনার কন্ট্রোল</span>
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
