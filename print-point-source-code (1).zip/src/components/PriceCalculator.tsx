import React, { useState, useMemo } from 'react';
import { 
  Calculator, 
  Check, 
  Sparkles, 
  Tag, 
  ArrowRight, 
  AlertCircle,
  FileCheck2,
  Clock
} from 'lucide-react';

interface PriceCalculatorProps {
  onProceedToOrder: (prefill: {
    serviceName: string;
    qty: string;
    estimatedPrice: number;
    notes: string;
    urgent: boolean;
  }) => void;
}

export const PriceCalculator: React.FC<PriceCalculatorProps> = ({ onProceedToOrder }) => {
  const [serviceType, setServiceType] = useState<'b_w' | 'color' | 'photo' | 'typing' | 'lamination' | 'scan'>('b_w');
  const [pages, setPages] = useState<number>(10);
  const [paperSide, setPaperSide] = useState<'single' | 'double'>('single');
  const [paperType, setPaperType] = useState<'standard' | 'heavy' | 'photo'>('standard');
  const [urgent, setUrgent] = useState<boolean>(false);
  const [couponCode, setCouponCode] = useState<string>('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [couponMsg, setCouponMsg] = useState<{ text: string; error: boolean } | null>(null);

  // Calculation logic
  const calculation = useMemo(() => {
    let baseRatePerPage = 2;
    let serviceLabel = 'সাদাকালো ফটোকপি ও প্রিন্ট';

    if (serviceType === 'b_w') {
      baseRatePerPage = paperSide === 'double' ? 3.5 : 2;
      if (paperType === 'heavy') baseRatePerPage += 1;
      serviceLabel = `সাদাকালো প্রিন্ট (${paperSide === 'double' ? 'উভয় পিঠ' : 'এক পিঠ'})`;
    } else if (serviceType === 'color') {
      baseRatePerPage = paperType === 'heavy' ? 18 : 10;
      serviceLabel = `রঙিন কালার প্রিন্ট (${paperType === 'heavy' ? 'গ্লসি পেপার' : 'সাধারণ পেপার'})`;
    } else if (serviceType === 'photo') {
      baseRatePerPage = 7.5; // ~30 for 4 copies
      serviceLabel = 'ল্যাব কোয়ালিটি ছবি প্রিন্ট';
    } else if (serviceType === 'typing') {
      baseRatePerPage = 15;
      serviceLabel = 'কম্পিউটার টাইপিং ও কম্পোজ';
    } else if (serviceType === 'lamination') {
      baseRatePerPage = paperType === 'standard' ? 25 : 35;
      serviceLabel = 'প্রিমিয়াম লেমিনেশন সেবা';
    } else if (serviceType === 'scan') {
      baseRatePerPage = 10;
      serviceLabel = 'হাই রেজোলিউশন স্ক্যান ও ডিজিটাল কপি';
    }

    const subtotal = Math.round(baseRatePerPage * pages);
    const urgentFee = urgent ? 25 : 0;
    let discount = 0;

    if (appliedCoupon === 'PRINT20') {
      discount = Math.min(Math.round(subtotal * 0.20), 100);
    } else if (appliedCoupon === 'STUDENT10') {
      discount = Math.min(Math.round(subtotal * 0.10), 50);
    }

    const total = Math.max(subtotal + urgentFee - discount, 10);

    return {
      serviceLabel,
      baseRatePerPage,
      subtotal,
      urgentFee,
      discount,
      total
    };
  }, [serviceType, pages, paperSide, paperType, urgent, appliedCoupon]);

  const handleApplyCoupon = () => {
    const code = couponCode.trim().toUpperCase();
    if (code === 'PRINT20' || code === 'STUDENT10') {
      setAppliedCoupon(code);
      setCouponMsg({ text: `কুপন কোড ${code} সফলভাবে যুক্ত হয়েছে!`, error: false });
    } else if (code === '') {
      setAppliedCoupon(null);
      setCouponMsg(null);
    } else {
      setCouponMsg({ text: 'অবৈধ বা মেয়াদোত্তীর্ণ কুপন কোড!', error: true });
    }
  };

  const handleOrderTransfer = () => {
    onProceedToOrder({
      serviceName: calculation.serviceLabel,
      qty: `${pages} পৃষ্ঠা/কপি (${paperSide === 'double' ? 'উভয় পিঠ' : 'এক পিঠ'})`,
      estimatedPrice: calculation.total,
      notes: `ক্যালকুলেটর হিসাব: পেপার: ${paperType === 'heavy' ? 'হাই কোয়ালিটি/গ্লসি' : 'স্ট্যান্ডার্ড'}, সাবটোটাল: ৳${calculation.subtotal}${appliedCoupon ? `, কুপন: ${appliedCoupon}` : ''}`,
      urgent: urgent
    });
  };

  return (
    <section id="calculator" className="max-w-7xl mx-auto px-4 sm:px-8 py-14 scroll-mt-16">
      <div className="bg-gradient-to-br from-white via-slate-50 to-blue-50/50 rounded-3xl p-6 sm:p-10 border border-slate-200/80 shadow-md">
        
        {/* Title */}
        <div className="text-center max-w-xl mx-auto mb-8">
          <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-rose-600 bg-rose-50 px-3 py-1 rounded-full border border-rose-200">
            <Calculator className="w-3.5 h-3.5" />
            স্মার্ট অনলাইন ক্যালকুলেটর
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-[#031B4E] mt-2">
            অর্ডারের আগেই সঠিক খরচ জানুন
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            কোনো লুকায়িত চার্জ নেই, আপনার প্রয়োজন অনুযায়ী খরচ হিসাব করে এক ক্লিকে অর্ডার দিন
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Controls Form */}
          <div className="lg:col-span-7 space-y-5">
            
            {/* Service Type Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-2">
                ১. সেবার ধরন নির্বাচন করুন:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {[
                  { key: 'b_w', title: 'সাদাকালো ফটোকপি/প্রিন্ট' },
                  { key: 'color', title: 'রঙিন কালার প্রিন্ট' },
                  { key: 'photo', title: 'পাসপোর্ট/স্ট্যাম্প ছবি' },
                  { key: 'typing', title: 'বাংলা/ইংরেজি টাইপিং' },
                  { key: 'lamination', title: 'লেমিনেশন সেবা' },
                  { key: 'scan', title: 'স্ক্যান ও ইমেইল' }
                ].map((s) => (
                  <button
                    key={s.key}
                    type="button"
                    onClick={() => setServiceType(s.key as any)}
                    className={`p-3 rounded-xl text-left border text-xs font-bold transition flex items-center justify-between ${
                      serviceType === s.key
                        ? 'bg-[#031B4E] text-white border-[#031B4E] shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span>{s.title}</span>
                    {serviceType === s.key && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 ml-1" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity / Pages Slider */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200">
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-bold text-slate-700">
                  ২. পৃষ্ঠা / কপি সংখ্যা:
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="5000"
                    value={pages}
                    onChange={(e) => setPages(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-20 px-2 py-1 text-center font-bold text-sm bg-slate-50 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  <span className="text-xs text-slate-500 font-semibold">কপি/পাতা</span>
                </div>
              </div>

              <input
                type="range"
                min="1"
                max="200"
                value={pages > 200 ? 200 : pages}
                onChange={(e) => setPages(parseInt(e.target.value))}
                className="w-full accent-[#0F4C81] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>১ কপি</span>
                <span>৫০ কপি</span>
                <span>১০০ কপি</span>
                <span>২০০+ কপি</span>
              </div>
            </div>

            {/* Side & Quality Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Duplex / Single */}
              {(serviceType === 'b_w' || serviceType === 'color') && (
                <div className="bg-white p-3.5 rounded-xl border border-slate-200">
                  <label className="block text-xs font-bold text-slate-700 mb-2">
                    মুদ্রণ পক্ষ (Print Sides):
                  </label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setPaperSide('single')}
                      className={`py-2 rounded-lg font-bold border transition ${
                        paperSide === 'single'
                          ? 'bg-blue-50 text-[#0F4C81] border-blue-400'
                          : 'bg-slate-50 text-slate-600 border-slate-200'
                      }`}
                    >
                      এক পিঠ (Single)
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaperSide('double')}
                      className={`py-2 rounded-lg font-bold border transition ${
                        paperSide === 'double'
                          ? 'bg-blue-50 text-[#0F4C81] border-blue-400'
                          : 'bg-slate-50 text-slate-600 border-slate-200'
                      }`}
                    >
                      উভয় পিঠ (Double)
                    </button>
                  </div>
                </div>
              )}

              {/* Paper Quality */}
              <div className="bg-white p-3.5 rounded-xl border border-slate-200">
                <label className="block text-xs font-bold text-slate-700 mb-2">
                  কাগজের কোয়ালিটি:
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setPaperType('standard')}
                    className={`py-2 rounded-lg font-bold border transition ${
                      paperType === 'standard'
                        ? 'bg-blue-50 text-[#0F4C81] border-blue-400'
                        : 'bg-slate-50 text-slate-600 border-slate-200'
                    }`}
                  >
                    ৭০-৮০ gsm স্ট্যান্ডার্ড
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaperType('heavy')}
                    className={`py-2 rounded-lg font-bold border transition ${
                      paperType === 'heavy'
                        ? 'bg-blue-50 text-[#0F4C81] border-blue-400'
                        : 'bg-slate-50 text-slate-600 border-slate-200'
                    }`}
                  >
                    ১০০+ gsm প্রিমিয়াম
                  </button>
                </div>
              </div>

            </div>

            {/* Urgent & Coupon Row */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white p-3.5 rounded-xl border border-slate-200">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700 select-none">
                <input
                  type="checkbox"
                  checked={urgent}
                  onChange={(e) => setUrgent(e.target.checked)}
                  className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500"
                />
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-rose-600" />
                  তাৎক্ষণিক জরুরি ডেলিভারি (+৳ ২৫)
                </span>
              </label>

              {/* Coupon mini apply */}
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <input
                  type="text"
                  placeholder="কুপন (PRINT20)"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="w-full sm:w-28 text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 outline-none uppercase font-bold"
                />
                <button
                  type="button"
                  onClick={handleApplyCoupon}
                  className="bg-[#031B4E] hover:bg-[#0F4C81] text-white px-3 py-1.5 rounded-lg text-xs font-bold transition shrink-0"
                >
                  প্রয়োগ
                </button>
              </div>
            </div>

            {couponMsg && (
              <p className={`text-xs font-semibold ${couponMsg.error ? 'text-rose-600' : 'text-emerald-600'}`}>
                {couponMsg.text}
              </p>
            )}

          </div>

          {/* Result & Breakdown Card */}
          <div className="lg:col-span-5 bg-[#031B4E] text-white rounded-2xl p-6 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none"></div>

            <div className="flex items-center justify-between border-b border-blue-900 pb-4 mb-4">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-amber-400" />
                <h3 className="font-extrabold text-base text-white">আনুমানিক খরচের সারাংশ</h3>
              </div>
              <span className="text-[11px] bg-white/10 text-amber-300 font-bold px-2 py-0.5 rounded-full">
                স্মার্ট হিসাব
              </span>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <div className="flex justify-between">
                <span>নির্বাচিত সেবা:</span>
                <span className="font-bold text-white text-right max-w-[200px] truncate">{calculation.serviceLabel}</span>
              </div>
              <div className="flex justify-between">
                <span>পরিমাণ / পৃষ্ঠা:</span>
                <span className="font-bold text-white">{pages} টি</span>
              </div>
              <div className="flex justify-between">
                <span>প্রতি পাতা গড় দর:</span>
                <span className="font-bold text-white">৳ {calculation.baseRatePerPage}</span>
              </div>
              <div className="flex justify-between">
                <span>মোট উপযোগ মূল্য (Subtotal):</span>
                <span className="font-bold text-white">৳ {calculation.subtotal}</span>
              </div>

              {urgent && (
                <div className="flex justify-between text-rose-300">
                  <span>জরুরি ডেলিভারি ফি:</span>
                  <span className="font-bold">+৳ {calculation.urgentFee}</span>
                </div>
              )}

              {calculation.discount > 0 && (
                <div className="flex justify-between text-emerald-400 font-bold">
                  <span>কুপন ডিসকাউন্ট ({appliedCoupon}):</span>
                  <span>-৳ {calculation.discount}</span>
                </div>
              )}

              <div className="border-t border-blue-800/80 pt-3 mt-2 flex justify-between items-baseline">
                <div>
                  <span className="text-xs text-slate-400 block">সর্বমোট পরিশোধযোগ্য:</span>
                  <span className="text-2xl sm:text-3xl font-black text-amber-400">
                    ৳ {calculation.total}
                  </span>
                </div>
                <span className="text-[11px] text-emerald-400 font-semibold bg-emerald-950/60 px-2 py-1 rounded border border-emerald-500/30">
                  সব ট্যাক্স সহ
                </span>
              </div>
            </div>

            <div className="mt-6 space-y-2">
              <button
                type="button"
                onClick={handleOrderTransfer}
                className="w-full bg-rose-600 hover:bg-rose-700 text-white font-black py-3 rounded-xl transition shadow-lg flex items-center justify-center gap-2 text-sm active:scale-95"
              >
                <span>এই হিসাব দিয়ে সরাসরি অর্ডার করুন</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <p className="text-[11px] text-center text-blue-200/80">
                ক্লিক করলে সরাসরি অর্ডার ফরমে হিসাবটি স্বয়ংক্রিয়ভাবে পূরণ হবে
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
