import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { ShopConfig } from '../types';

interface FloatingWhatsAppProps {
  shopConfig: ShopConfig;
  onOpenOrderModal: () => void;
}

export const FloatingWhatsApp: React.FC<FloatingWhatsAppProps> = ({ shopConfig, onOpenOrderModal }) => {
  const [tooltipVisible, setTooltipVisible] = useState(true);

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2">
      {/* Tooltip speech bubble */}
      {tooltipVisible && (
        <div className="bg-white text-slate-800 text-xs py-2 px-3.5 rounded-2xl shadow-xl border border-slate-200 flex items-center gap-2 max-w-[220px] animate-bounce">
          <p className="font-semibold text-[11px] leading-tight">
            যেকোনো সহায়তায় সরাসরি <strong>WhatsApp</strong>-এ মেসেজ দিন!
          </p>
          <button
            onClick={() => setTooltipVisible(false)}
            className="text-slate-400 hover:text-slate-600 p-0.5"
            aria-label="Close tooltip"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Buttons Group */}
      <div className="flex items-center gap-2">
        <a
          href={`https://wa.me/${shopConfig.whatsapp}?text=${encodeURIComponent(
            `আসসালামু আলাইকুম, প্রিন্ট পয়েন্ট থেকে সেবা নিতে চাচ্ছি।`
          )}`}
          target="_blank"
          rel="noopener noreferrer"
          className="w-14 h-14 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 transform hover:scale-110 active:scale-95 group relative"
          aria-label="Chat on WhatsApp"
        >
          {/* Pulsing halo */}
          <span className="absolute inset-0 rounded-full bg-emerald-400 animate-ping opacity-30"></span>
          <MessageCircle className="w-7 h-7 relative z-10" />
        </a>
      </div>
    </div>
  );
};
