import React from 'react';

interface PrintPointLogoProps {
  size?: 'sm' | 'md' | 'lg';
  theme?: 'dark' | 'light';
  showTagline?: boolean;
}

export const PrintPointLogo: React.FC<PrintPointLogoProps> = ({ 
  size = 'md', 
  theme = 'light',
  showTagline = true 
}) => {
  const iconSize = size === 'sm' ? 36 : size === 'lg' ? 54 : 44;
  const titleSize = size === 'sm' ? 'text-xl' : size === 'lg' ? 'text-3xl' : 'text-2xl';
  const taglineSize = size === 'sm' ? 'text-[9px]' : size === 'lg' ? 'text-xs' : 'text-[11px]';

  return (
    <div className="flex items-center gap-3 select-none">
      {/* High-impact Vector Logo Icon */}
      <div 
        className="relative shrink-0 flex items-center justify-center p-1.5 rounded-2xl shadow-sm transition transform hover:scale-105"
        style={{ width: iconSize, height: iconSize }}
      >
        <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-md">
          {/* Outer dynamic curved swoosh / speed circle */}
          <circle cx="50" cy="50" r="46" stroke="url(#logo_grad_blue)" strokeWidth="6" strokeDasharray="180 80" strokeLinecap="round" />
          <circle cx="50" cy="50" r="46" stroke="url(#logo_grad_red)" strokeWidth="6" strokeDasharray="60 200" strokeDashoffset="120" strokeLinecap="round" />

          {/* Printer Body */}
          <rect x="22" y="38" width="56" height="34" rx="7" fill="url(#logo_grad_printer)" />
          
          {/* Top Paper Feed */}
          <path d="M32 20 H68 V38 H32 Z" fill="#F8FAFC" stroke="#94A3B8" strokeWidth="2" strokeLinejoin="round" />
          <line x1="38" y1="26" x2="62" y2="26" stroke="#0F4C81" strokeWidth="2" strokeLinecap="round" />
          <line x1="38" y1="31" x2="56" y2="31" stroke="#D90429" strokeWidth="2" strokeLinecap="round" />

          {/* Paper Output Slot & Printed Sheet */}
          <rect x="28" y="52" width="44" height="4" rx="2" fill="#031B4E" />
          <path d="M30 55 H70 V78 H30 Z" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1.5" />
          
          {/* Color CMYK Print Stripes */}
          <rect x="35" y="60" width="7" height="12" rx="1" fill="#00E5FF" />
          <rect x="43" y="60" width="7" height="12" rx="1" fill="#FF1744" />
          <rect x="51" y="60" width="7" height="12" rx="1" fill="#FFD600" />
          <rect x="59" y="60" width="7" height="12" rx="1" fill="#031B4E" />

          {/* Glowing Status Light */}
          <circle cx="70" cy="45" r="2.5" fill="#10B981" />

          {/* Definitions */}
          <defs>
            <linearGradient id="logo_grad_blue" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#0F4C81" />
              <stop offset="100%" stopColor="#00B4D8" />
            </linearGradient>
            <linearGradient id="logo_grad_red" x1="0" y1="100" x2="100" y2="0" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#D90429" />
              <stop offset="100%" stopColor="#FF5252" />
            </linearGradient>
            <linearGradient id="logo_grad_printer" x1="22" y1="38" x2="78" y2="72" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#0A2540" />
              <stop offset="100%" stopColor="#031B4E" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Typography */}
      <div className="flex flex-col justify-center">
        <div className={`font-black tracking-tight leading-none flex items-center ${titleSize}`}>
          <span className={theme === 'dark' ? 'text-white' : 'text-[#031B4E]'}>
            PRINT
          </span>
          <span className="text-rose-600 ml-1.5 drop-shadow-sm">
            POINT
          </span>
        </div>

        {showTagline && (
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="w-3 h-0.5 bg-rose-600 rounded-full"></span>
            <span className={`font-semibold tracking-wider italic ${taglineSize} ${
              theme === 'dark' ? 'text-blue-200' : 'text-slate-500'
            }`}>
              Your Digital Service Partner
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
