import React, { useState } from 'react';
import { 
  Zap, 
  CreditCard, 
  ShieldCheck, 
  Headphones, 
  Tag, 
  Clock, 
  Gift, 
  ArrowRight, 
  ListOrdered, 
  Crown, 
  Search, 
  MessageCircle,
  CheckCircle2,
  Upload,
  ShoppingBag,
  Send
} from 'lucide-react';
import { ShopConfig, Order } from '../types';

interface QuickActionSectionProps {
  shopConfig: ShopConfig;
  onOpenOrderModal: (serviceName?: string) => void;
  orders: Order[];
  onTrackOrder: (orderId: string) => void;
}

export const QuickActionSection: React.FC<QuickActionSectionProps> = ({
  shopConfig,
  onOpenOrderModal,
  orders,
  onTrackOrder
}) => {
  const [trackQuery, setTrackQuery] = useState('');

  const handleTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (trackQuery.trim()) {
      onTrackOrder(trackQuery.trim());
      // smooth scroll to order-track section
      const el = document.getElementById('order-track');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 space-y-6">
      
      {/* 1. TRUST BAR (Exactly matching mockup) */}
      <div className="bg-[#031B4E] text-white rounded-2xl p-3 sm:p-4 shadow-md border border-blue-900 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-bold text-center">
        
        <div className="flex items-center justify-center gap-2 p-1.5 border-r border-blue-900/60 last:border-0">
          <Zap className="w-4 h-4 text-amber-400 fill-amber-400 shrink-0" />
          <span className="leading-tight">অনলাইন অর্ডার <br /><span className="text-[10px] text-amber-300 font-normal">(লগইন ছাড়াই!)</span></span>
        </div>

        <div className="flex items-center justify-center gap-2 p-1.5 border-r border-blue-900/60 last:border-0">
          <CreditCard className="w-4 h-4 text-rose-400 shrink-0" />
          <span className="leading-tight">বিকাশ, নগদ ও <br /><span className="text-[10px] text-slate-300 font-normal">অন্যান্য পেমেন্ট</span></span>
        </div>

        <div className="flex items-center justify-center gap-2 p-1.5 border-r border-blue-900/60 last:border-0">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="leading-tight">নিরাপদ ও <br /><span className="text-[10px] text-slate-300 font-normal">সুরক্ষিত তথ্য</span></span>
        </div>

        <div className="flex items-center justify-center gap-2 p-1.5 border-r border-blue-900/60 last:border-0">
          <Headphones className="w-4 h-4 text-cyan-400 shrink-0" />
          <span className="leading-tight">দ্রুত সাপোর্ট <br /><span className="text-[10px] text-cyan-300 font-normal">(WhatsApp)</span></span>
        </div>

        <div className="flex items-center justify-center gap-2 p-1.5 border-r border-blue-900/60 last:border-0">
          <Tag className="w-4 h-4 text-yellow-400 shrink-0" />
          <span className="leading-tight">নিয়মিত <br /><span className="text-[10px] text-amber-300 font-normal">ডিসকাউন্ট</span></span>
        </div>

        <div className="flex items-center justify-center gap-2 p-1.5">
          <Clock className="w-4 h-4 text-blue-400 shrink-0" />
          <span className="leading-tight">২৪/৭ অনলাইন <br /><span className="text-[10px] text-slate-300 font-normal">অর্ডার সেবা</span></span>
        </div>

      </div>

      {/* 2. FOUR QUICK ACTION CARDS (Exactly matching the reference image!) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4 sm:gap-5 items-stretch">
        
        {/* CARD 1: আজকের বিশেষ অফার (3 cols on lg) */}
        <div className="lg:col-span-3 bg-gradient-to-br from-rose-50 via-white to-red-50 rounded-2xl p-5 border-2 border-rose-200 shadow-sm flex flex-col justify-between relative overflow-hidden">
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-rose-600 text-white text-[11px] font-black px-2.5 py-0.5 rounded-full flex items-center gap-1">
              <Gift className="w-3.5 h-3.5" />
              <span>আজকের বিশেষ অফার</span>
            </span>
          </div>

          <div>
            <h4 className="text-lg sm:text-xl font-black text-slate-900 leading-tight">
              সকল সেবায় <span className="text-rose-600">{shopConfig.globalDiscountPercent || 20}%</span> পর্যন্ত ছাড়!
            </h4>
            <p className="text-xs text-slate-500 mt-1 font-medium">
              অফারটি সীমিত সময়ের জন্য প্রযোজ্য
            </p>
          </div>

          <button
            onClick={() => onOpenOrderModal('২০% ডিসকাউন্ট স্পেশাল অফার')}
            className="w-full bg-rose-600 hover:bg-rose-700 text-white font-black text-xs py-2.5 rounded-xl transition shadow flex items-center justify-center gap-1.5 mt-4 cursor-pointer"
          >
            <span>এখনই অর্ডার করুন</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* CARD 2: কাজের সহজ ৪টি ধাপ (4 cols on lg) */}
        <div className="lg:col-span-4 bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center gap-1.5 text-xs font-black text-[#031B4E] mb-3">
            <ListOrdered className="w-4 h-4 text-blue-600" />
            <span>কাজের সহজ ধাপসমূহ</span>
          </div>

          {/* 4 Steps timeline icons */}
          <div className="grid grid-cols-4 gap-2 text-center text-[10px] font-bold text-slate-700 my-auto">
            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-black mb-1">
                ১
              </div>
              <span className="leading-tight">সেবা নির্বাচন</span>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center font-black mb-1">
                ২
              </div>
              <span className="leading-tight">ফাইল আপলোড</span>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center font-black mb-1">
                ৩
              </div>
              <span className="leading-tight">পেমেন্ট / ক্যাশ</span>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-black mb-1">
                ৪
              </div>
              <span className="leading-tight">কাজ ডেলিভারি</span>
            </div>
          </div>

          <div className="text-[11px] text-center text-slate-500 font-medium mt-3 bg-slate-50 py-1.5 rounded-lg border border-slate-100">
            ঘরে বসেই ফাইল পাঠিয়ে কাজ বুঝে নিন
          </div>
        </div>

        {/* CARD 3: আমাদের বিশেষ সুবিধা (2 cols on lg) */}
        <div className="lg:col-span-2 bg-[#031B4E] text-white rounded-2xl p-4 border border-blue-900 shadow-sm flex flex-col justify-between text-xs">
          <div className="flex items-center gap-1.5 font-black text-amber-400 mb-2">
            <Crown className="w-4 h-4" />
            <span className="text-[11px]">আমাদের বিশেষ সুবিধা</span>
          </div>

          <ul className="space-y-1.5 text-[11px] text-slate-200 font-semibold my-auto">
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>মূল্য পরিবর্তন সুবিধা</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>ডিসকাউন্ট দেওয়ার সুবিধা</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>ম্যানুয়াল অর্ডার কনফার্ম</span>
            </li>
            <li className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>পূর্ণাঙ্গ Admin Panel</span>
            </li>
          </ul>
        </div>

        {/* CARD 4: অর্ডার ট্র্যাক ও WhatsApp (3 cols on lg) */}
        <div className="lg:col-span-3 bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-bold text-slate-800 mb-2">
            <span>অর্ডার ট্র্যাক করুন</span>
            <span className="text-[10px] text-slate-400 font-mono">যেমন: PP-1001</span>
          </div>

          <form onSubmit={handleTrackSubmit} className="flex gap-1.5 mb-2.5">
            <input
              type="text"
              placeholder="অর্ডার নম্বর লিখুন..."
              value={trackQuery}
              onChange={(e) => setTrackQuery(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs outline-none focus:ring-1 focus:ring-blue-600 font-bold uppercase"
            />
            <button
              type="submit"
              className="bg-[#031B4E] hover:bg-[#0F4C81] text-white px-3 py-1.5 rounded-lg text-xs font-bold shrink-0 transition"
            >
              খুঁজুন
            </button>
          </form>

          <a
            href={`https://wa.me/${shopConfig.whatsapp}?text=${encodeURIComponent(
              `আসসালামু আলাইকুম প্রিন্ট পয়েন্ট, আমি একটি অর্ডার সংক্রান্ত তথ্য জানতে চাচ্ছি।`
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 rounded-xl transition shadow flex items-center justify-center gap-1.5"
          >
            <MessageCircle className="w-4 h-4" />
            <span>WhatsApp-এ যোগাযোগ করুন</span>
          </a>
        </div>

      </div>

    </div>
  );
};
