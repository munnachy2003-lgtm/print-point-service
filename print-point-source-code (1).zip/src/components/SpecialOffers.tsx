import React, { useState } from 'react';
import { Tag, Sparkles, Copy, Check, ArrowRight, Gift, Percent } from 'lucide-react';
import { Coupon } from '../types';

interface SpecialOffersProps {
  coupons: Coupon[];
  onClaimOffer: (couponCode: string) => void;
}

export const SpecialOffers: React.FC<SpecialOffersProps> = ({ coupons, onClaimOffer }) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => {
      setCopiedCode(null);
    }, 2500);
  };

  return (
    <section id="offers" className="max-w-7xl mx-auto px-4 sm:px-8 py-14 scroll-mt-16">
      
      {/* Big Hero Promo Banner */}
      <div className="bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 text-white rounded-3xl p-6 sm:p-10 shadow-xl relative overflow-hidden">
        {/* Background icon watermark */}
        <div className="absolute -right-8 -bottom-8 text-white/10 text-9xl pointer-events-none">
          <Tag className="w-56 h-56 -rotate-12" />
        </div>
        
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 bg-amber-400 text-[#031B4E] font-black text-xs px-3.5 py-1 rounded-full uppercase tracking-wider shadow-sm">
            <Gift className="w-3.5 h-3.5" />
            🎉 স্পেশাল মেগা ডিসকাউন্ট অফার
          </span>

          <h2 className="text-2xl sm:text-4xl font-black mt-3 leading-tight">
            একসাথে একাধিক প্রিন্ট ও ফাইলে ২০% পর্যন্ত সরাসরি ছাড়!
          </h2>

          <p className="text-xs sm:text-sm text-red-100 mt-2.5 font-normal leading-relaxed">
            যেকোনো অ্যাসাইনমেন্ট বা প্রজেক্ট পেপার প্রিন্ট, বই স্পাইরাল বাইন্ডিং কিংবা স্টুডেন্টদের জন্য থাকছে বিশেষ মূল্যছাড়। আজই অর্ডার করুন এবং আপনার কুপন কোড ব্যবহার করে সাশ্রয় করুন।
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-6">
            <div className="bg-white/20 backdrop-blur-md border border-white/30 px-4 py-2 rounded-xl text-center flex items-center gap-3">
              <div>
                <span className="text-[10px] text-red-200 block uppercase font-bold">কুপন কোড</span>
                <span className="text-base font-black text-amber-300">PRINT20</span>
              </div>
              <button
                onClick={() => handleCopy('PRINT20')}
                className="p-1.5 bg-white/15 hover:bg-white/30 rounded-lg text-white transition"
                title="কপি করুন"
              >
                {copiedCode === 'PRINT20' ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <button 
              onClick={() => onClaimOffer('PRINT20')} 
              className="bg-white text-rose-600 hover:bg-amber-300 hover:text-[#031B4E] font-black px-6 py-3 rounded-xl shadow-lg transition text-xs sm:text-sm flex items-center gap-2 active:scale-95"
            >
              <span>অফারটি গ্রহণ করুন</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Available Coupon Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        {coupons.map((coupon) => (
          <div
            key={coupon.code}
            className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between hover:border-blue-400 transition"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="inline-flex items-center gap-1 text-xs font-bold text-[#0F4C81] bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                  <Percent className="w-3 h-3 text-rose-600" />
                  {coupon.discountPercent}% ছাড়
                </span>
                <span className="text-[11px] text-slate-400">সর্বোচ্চ ৳{coupon.maxDiscount}</span>
              </div>

              <h4 className="font-bold text-slate-800 text-sm">{coupon.description}</h4>
              <p className="text-[11px] text-slate-500 mt-1">সর্বনিম্ন অর্ডার মূল্য: ৳{coupon.minOrder}</p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="font-mono font-black text-xs text-rose-600 bg-rose-50 px-2 py-1 rounded border border-rose-200">
                {coupon.code}
              </span>
              <button
                onClick={() => {
                  handleCopy(coupon.code);
                  onClaimOffer(coupon.code);
                }}
                className="text-xs font-bold text-[#0F4C81] hover:text-rose-600 transition flex items-center gap-1"
              >
                <span>ব্যবহার করুন</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>

    </section>
  );
};
